// pdm_channel.v
// -----------------------------------------------------------------------------
// One microphone channel, 50 MHz domain with clock enables (no derived clocks).
// Identical arithmetic to the verified single-mic test:
//   1-bit PDM -> 3rd-order CIC (R=16, 3.125 MHz -> 195.3125 kHz)
//             -> DC blocker -> 2-pole low-pass (~3.9 kHz per pole)
// Also reports the raw PDM ones-density (0x80 = healthy) and a log2 peak level.
// All four instances receive the same pdm_ce, so their decimation phases and
// pipeline latencies are identical (required for beamforming).
// -----------------------------------------------------------------------------
module pdm_channel (
    input  wire               clk,        // 50 MHz
    input  wire               rst_n,
    input  wire               pdm_ce,     // 1-cycle pulse at 3.125 MHz
    input  wire               pdm_bit,    // recovered PDM bit (valid when pdm_ce)
    output wire signed [15:0] audio,      // band-limited audio, ~ +/-16384 full scale
    output wire signed [15:0] audio_hp,   // audio with < ~1 kHz removed (beamformer)
    output reg                audio_ce,   // 1-cycle pulse at 195.3125 kHz
    output reg  [7:0]         density,    // ones per 1024 bits / 4  (0x80 = 50 %)
    output wire [4:0]         level       // log2 of peak |audio| (1 step = 6 dB)
);

    // ---------------- Raw PDM ones-density -----------------------------------
    reg  [9:0]  dn;
    reg  [10:0] ones;
    wire [10:0] ones_next = ones + {10'd0, pdm_bit};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dn <= 10'd0; ones <= 11'd0; density <= 8'd0;
        end else if (pdm_ce) begin
            dn <= dn + 10'd1;
            if (dn == 10'd1023) begin
                density <= ones_next[10] ? 8'hFF : ones_next[9:2];
                ones    <= 11'd0;
            end else begin
                ones    <= ones_next;
            end
        end
    end

    // ---------------- 3rd-order CIC, R = 16 ----------------------------------
    wire signed [15:0] d_in = pdm_bit ? 16'sd1 : -16'sd1;

    reg signed [15:0] int1, int2, int3;
    reg signed [15:0] c0_d, comb1, comb1_d, comb2, comb2_d, comb3;
    reg [3:0]         dec_cnt;
    reg               cic_ce;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            int1 <= 16'sd0; int2 <= 16'sd0; int3 <= 16'sd0;
            c0_d <= 16'sd0; comb1 <= 16'sd0; comb1_d <= 16'sd0;
            comb2 <= 16'sd0; comb2_d <= 16'sd0; comb3 <= 16'sd0;
            dec_cnt <= 4'd0; cic_ce <= 1'b0;
        end else begin
            cic_ce <= 1'b0;
            if (pdm_ce) begin
                int1    <= int1 + d_in;
                int2    <= int2 + int1;
                int3    <= int3 + int2;
                dec_cnt <= dec_cnt + 4'd1;
                if (dec_cnt == 4'd15) begin
                    comb1   <= int3  - c0_d;    c0_d    <= int3;
                    comb2   <= comb1 - comb1_d; comb1_d <= comb1;
                    comb3   <= comb2 - comb2_d; comb2_d <= comb2;
                    cic_ce  <= 1'b1;
                end
            end
        end
    end

    // ---------------- DC blocker + 2-pole low-pass ---------------------------
    wire signed [15:0] raw_pcm = {comb3[13:0], 2'b00};

    reg signed [23:0] dc_est;
    reg signed [15:0] pcm;
    reg signed [23:0] lp1, lp2;
    reg               pcm_ce;

    wire signed [23:0] pcm_x = {{4{pcm[15]}}, pcm, 4'b0000};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dc_est <= 24'sd0; pcm <= 16'sd0; lp1 <= 24'sd0; lp2 <= 24'sd0;
            pcm_ce <= 1'b0; audio_ce <= 1'b0;
        end else begin
            pcm_ce   <= cic_ce;
            audio_ce <= pcm_ce;
            if (cic_ce) begin
                dc_est <= dc_est + ({{8{raw_pcm[15]}}, raw_pcm} - {{8{dc_est[23]}}, dc_est[23:8]});
                pcm    <= raw_pcm - dc_est[23:8];
            end
            if (pcm_ce) begin
                lp1 <= lp1 + ((pcm_x - lp1) >>> 3);
                lp2 <= lp2 + ((lp1   - lp2) >>> 3);
            end
        end
    end

    assign audio = lp2[19:4];

    // ---------------- 1st-order high-pass (~1 kHz) for the beamformer -------
    // Low frequencies carry most room noise but give no direction information
    // with a ~3 cm array, so the beamformer path removes them.
    // audio_hp[n] = audio[n] - lpf[n-1]; valid during audio_ce.
    reg  signed [23:0] hp_lp;
    wire signed [23:0] a_x = {{4{audio[15]}}, audio, 4'b0000};
    wire signed [23:0] hp_full = a_x - hp_lp;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)        hp_lp <= 24'sd0;
        else if (audio_ce) hp_lp <= hp_lp + ((a_x - hp_lp) >>> 5);
    end

    assign audio_hp = hp_full[19:4];

    // ---------------- Peak level (log2) --------------------------------------
    wire [15:0] mag = audio[15] ? (~audio + 16'd1) : audio;
    reg  [15:0] peak;
    reg  [11:0] dcy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            peak <= 16'd0; dcy <= 12'd0;
        end else if (audio_ce) begin
            dcy <= dcy + 12'd1;
            if (mag > peak)        peak <= mag;
            else if (dcy == 12'd0) peak <= peak - ((peak >> 3) | {15'd0, (|peak)});
        end
    end

    function [4:0] msb_pos16(input [15:0] v);
        integer j;
        begin
            msb_pos16 = 5'd0;
            for (j = 0; j < 16; j = j + 1)
                if (v[j]) msb_pos16 = j + 1;
        end
    endfunction

    assign level = msb_pos16(peak);

endmodule
