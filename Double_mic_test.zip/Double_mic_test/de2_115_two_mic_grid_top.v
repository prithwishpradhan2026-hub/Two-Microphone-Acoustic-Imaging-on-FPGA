// de2_115_two_mic_grid_top.v
// -----------------------------------------------------------------------------
// 2-microphone sound locator, DE2-115 + VGA, screen in the layout of the
// original acoustic camera with a 1x2 grid (left half = Mic 1 side, right half
// = Mic 2 side). Same verified processing as de2_115_two_mic_top.v.
//
// Mic 1 (left, SEL = GND) and Mic 2 (right, SEL = 3.3 V) share DAT (JP5 pin 3),
// sound ports 30.5 mm apart.
//
// Screen: square box = sound intensity by direction (columns) over time (rows,
//         newest at top); LOW blue -> MID green/yellow -> HIGH red.
//         Corner tags 1 / 2 (nearest mic amber). SOURCE DATA panel: NEAR, FREQ
//         (kHz), QUAD (CH 01 / CH 02), LVL1, LVL2. INTENSITY legend.
// Board: HEX7-6 Mic 1 level, HEX5-4 Mic 2 level, HEX3-0 frequency (Hz) of the
//        nearest mic; LEDG0/1 mic data healthy; LEDG8 sound above the gate;
//        LEDR7-0 / LEDR15-8 level bars.
// Controls: KEY0 reset; SW1-0 colour range (00 3 dB, 01 6 dB, 10 12 dB,
//           11 1.5 dB); SW5-2 raise noise gate; SW16 mirror left-right;
//           SW17 hold the image.
// -----------------------------------------------------------------------------
module de2_115_two_mic_grid_top #(
    parameter integer GATE_SAMPLES = 195312,   // frequency gate, 1.000 s
    parameter integer GATE_BASE    = 15,       // noise gate with SW5-2 = 0
    parameter integer WF_SHIFT     = 6         // history row every 2^WF_SHIFT sweeps
)(
    input  wire        CLOCK_50,
    input  wire [0:0]  KEY,
    input  wire [17:0] SW,
    output wire        GPIO_MIC_CLK,    // JP5 pin 1 (PIN_AB22) -> 33 ohm -> both CLK
    input  wire        GPIO_MIC_DAT0,   // JP5 pin 3 (PIN_AB21) <- Mic 1 (L) + Mic 2 (R)
    output wire        VGA_CLK,
    output wire        VGA_HS,
    output wire        VGA_VS,
    output wire        VGA_BLANK_N,
    output wire        VGA_SYNC_N,
    output wire [7:0]  VGA_R,
    output wire [7:0]  VGA_G,
    output wire [7:0]  VGA_B,
    output wire [17:0] LEDR,
    output wire [8:0]  LEDG,
    output wire [6:0]  HEX0, HEX1, HEX2, HEX3, HEX4, HEX5, HEX6, HEX7
);

    wire rst_n = KEY[0];

    // =========================================================================
    // 1. Mic clock (3.125 MHz) and capture
    // =========================================================================
    reg [3:0] div;                       // 0..7 CLK low, 8..15 CLK high
    always @(posedge CLOCK_50 or negedge rst_n)
        if (!rst_n) div <= 4'd0;
        else        div <= div + 4'd1;
    assign GPIO_MIC_CLK = div[3];

    reg d0_s1, d0_s2;
    always @(posedge CLOCK_50) begin
        d0_s1 <= GPIO_MIC_DAT0;
        d0_s2 <= d0_s1;
    end

    reg       r0;                        // Mic 2 bit (CLK-low half)
    reg [1:0] pdm_bits;                  // {Mic 2, Mic 1}
    reg       pdm_ce;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            r0 <= 1'b0; pdm_bits <= 2'd0; pdm_ce <= 1'b0;
        end else begin
            pdm_ce <= 1'b0;
            if (div == 4'd7)  r0 <= d0_s2;
            if (div == 4'd15) begin
                pdm_bits <= {r0, d0_s2};
                pdm_ce   <= 1'b1;
            end
        end
    end

    // =========================================================================
    // 2. Two channels
    // =========================================================================
    wire signed [15:0] audio    [0:1];
    wire signed [15:0] audio_hp [0:1];
    wire [1:0]         ach_ce;
    wire [7:0]         dens     [0:1];
    wire [4:0]         lvl      [0:1];

    genvar i;
    generate
        for (i = 0; i < 2; i = i + 1) begin : GEN_CH
            pdm_channel u_ch (
                .clk      (CLOCK_50),
                .rst_n    (rst_n),
                .pdm_ce   (pdm_ce),
                .pdm_bit  (pdm_bits[i]),
                .audio    (audio[i]),
                .audio_hp (audio_hp[i]),
                .audio_ce (ach_ce[i]),
                .density  (dens[i]),
                .level    (lvl[i])
            );
        end
    endgenerate

    wire sample_ce = ach_ce[0];

    // =========================================================================
    // 3. Ring buffers and direction sweep
    // =========================================================================
    reg [9:0] wr_ptr;
    always @(posedge CLOCK_50 or negedge rst_n)
        if (!rst_n)         wr_ptr <= 10'd0;
        else if (sample_ce) wr_ptr <= wr_ptr + 10'd1;

    reg [5:0] scan_cell;                      // screen column 0..32 (left..right)
    reg [8:0] lidx;                      // sample 0..511
    reg [9:0] base;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            scan_cell <= 6'd0; lidx <= 9'd0; base <= 10'd0;
        end else if (lidx == 9'd511) begin
            lidx <= 9'd0;
            if (scan_cell == 6'd32) begin
                scan_cell <= 6'd0;
                base <= wr_ptr;
            end else begin
                scan_cell <= scan_cell + 6'd1;
            end
        end else begin
            lidx <= lidx + 9'd1;
        end
    end

    // Physical direction: 0 = far Mic 1 side, 32 = far Mic 2 side.
    // A source on Mic 1's side reaches Mic 1 first, so Mic 1 is delayed more.
    wire [5:0]        dir  = SW[16] ? (6'd32 - scan_cell) : scan_cell;
    wire signed [6:0] tau1 = 7'sd16 - $signed({1'b0, dir});           // -16..+16

    wire [9:0] rd_base = base - 10'd20 - {1'b0, lidx};
    wire [9:0] rd1     = rd_base - {{3{tau1[6]}}, tau1};

    wire signed [15:0] dly0, dly1;
    mic_ring_buffer_1k u_ring0 (
        .clk(CLOCK_50), .we(sample_ce), .wr_addr(wr_ptr), .din(audio_hp[0]),
        .rd_addr(rd1),     .dout(dly0)
    );
    mic_ring_buffer_1k u_ring1 (
        .clk(CLOCK_50), .we(sample_ce), .wr_addr(wr_ptr), .din(audio_hp[1]),
        .rd_addr(rd_base), .dout(dly1)
    );

    // =========================================================================
    // 4. Delay-and-sum energy (pipelined)
    // =========================================================================
    reg        p1_last, p2_last;
    reg [5:0]  p1_cell, p2_cell;
    reg [33:0] sq2;

    wire signed [16:0] bsum = dly0 + dly1;
    wire signed [33:0] bsq  = bsum * bsum;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            p1_last <= 1'b0; p1_cell <= 6'd0;
            p2_last <= 1'b0; p2_cell <= 6'd0; sq2 <= 34'd0;
        end else begin
            p1_last <= (lidx == 9'd511);
            p1_cell <= scan_cell;
            p2_last <= p1_last;
            p2_cell <= p1_cell;
            sq2     <= bsq;
        end
    end

    reg [43:0] acc, cell_energy;
    reg        e_valid;
    reg [5:0]  e_cell;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            acc <= 44'd0; cell_energy <= 44'd0; e_valid <= 1'b0; e_cell <= 6'd0;
        end else if (p2_last) begin
            cell_energy <= acc + {10'd0, sq2};
            acc         <= 44'd0;
            e_valid     <= 1'b1;
            e_cell      <= p2_cell;
        end else begin
            acc         <= acc + {10'd0, sq2};
            e_valid     <= 1'b0;
        end
    end

    // =========================================================================
    // 5. log2, smoothing, intensity
    // =========================================================================
    function [5:0] msb44(input [43:0] x);
        integer j;
        begin
            msb44 = 6'd0;
            for (j = 0; j < 44; j = j + 1)
                if (x[j]) msb44 = j;
        end
    endfunction

    reg        v1;  reg [5:0] c1;  reg [43:0] en1;  reg [5:0] ex1;
    reg [14:0] smooth_ram [0:63];                // log2 energy, 6 fraction bits
    reg [14:0] sm_rd;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            v1 <= 1'b0; c1 <= 6'd0; en1 <= 44'd0; ex1 <= 6'd0;
        end else begin
            v1 <= e_valid;
            if (e_valid) begin
                c1  <= e_cell;
                en1 <= cell_energy;
                ex1 <= msb44(cell_energy);
            end
        end
    end

    wire [43:0] mant_sh = (ex1 >= 6'd3) ? (en1 >> (ex1 - 6'd3)) : (en1 << (6'd3 - ex1));
    reg        v2;  reg [5:0] c2;  reg [8:0] lg2;  reg [14:0] smo2;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            v2 <= 1'b0; c2 <= 6'd0; lg2 <= 9'd0; smo2 <= 15'd0;
        end else begin
            v2 <= v1;
            if (v1) begin
                c2   <= c1;
                lg2  <= {ex1, mant_sh[2:0]};
                smo2 <= sm_rd;
            end
        end
    end

    // sm += (new - sm) / 64
    wire signed [15:0] sm_diff = $signed({1'b0, lg2, 6'b000000}) - $signed({1'b0, smo2});
    wire signed [15:0] sm_step = sm_diff >>> 6;
    wire signed [15:0] sm_sum  = $signed({1'b0, smo2}) + sm_step;
    reg        v3;  reg [5:0] c3;  reg [14:0] sm3;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            v3 <= 1'b0; c3 <= 6'd0; sm3 <= 15'd0;
        end else begin
            v3 <= v2;
            if (v2) begin
                c3  <= c2;
                sm3 <= sm_sum[14:0];
            end
        end
    end

    always @(posedge CLOCK_50) begin
        if (v3) smooth_ram[c3] <= sm3;
        sm_rd <= smooth_ram[e_cell];
    end

    wire [8:0] lg_s = sm3[14:6];

    reg [7:0] win;  reg [2:0] wsh;
    always @(*) begin
        case (SW[1:0])
            2'b00:   begin win = 8'd8;  wsh = 3'd5; end   //  3 dB
            2'b01:   begin win = 8'd16; wsh = 3'd4; end   //  6 dB
            2'b10:   begin win = 8'd32; wsh = 3'd3; end   // 12 dB
            default: begin win = 8'd4;  wsh = 3'd6; end   // 1.5 dB
        endcase
    end

    localparam [5:0] GB = GATE_BASE;
    wire [5:0] gate_oct = GB + {2'b00, SW[5:2]};
    wire [8:0] gate_log = {gate_oct, 3'b000};

    reg [8:0] cur_max, prev_max;
    reg [5:0] cur_cell, prev_cell;
    reg       prev_active;
    reg [1:0] nearest;                   // 0 none, 1 Mic 1, 2 Mic 2, 3 equal
    reg       sweep_done;

    wire signed [10:0] rel = $signed({2'b00, lg_s}) + $signed({3'b000, win})
                           - $signed({2'b00, prev_max});
    wire [10:0] rel_sh = rel << wsh;
    wire [7:0]  inten  = !prev_active                     ? 8'd0   :
                         rel[10]                          ? 8'd0   :
                         (rel >= $signed({3'b000, win}))  ? 8'd255 :
                         rel_sh[7:0];

    wire [8:0] fm = (lg_s > cur_max) ? lg_s : cur_max;
    wire [5:0] fc = (lg_s > cur_max) ? c3   : cur_cell;

    // The beam of two mics 3 cm apart is flat near its top, so several columns
    // tie for the maximum. The peak is the middle of the run of columns within
    // 0.75 dB (2 LSB) of the previous sweep's maximum.
    wire [8:0] thr   = (prev_max > 9'd2) ? (prev_max - 9'd2) : 9'd0;
    wire       hit   = (lg_s >= thr);
    reg        cur_found;
    reg  [5:0] cur_first, cur_last;
    wire       f_found = cur_found | hit;
    wire [5:0] f_first = cur_found ? cur_first : c3;
    wire [5:0] f_last  = hit ? c3 : cur_last;
    wire [6:0] f_sum   = {1'b0, f_first} + {1'b0, f_last};
    wire [5:0] pk      = f_found ? f_sum[6:1] : fc;
    wire [5:0] pdir    = SW[16] ? (6'd32 - pk) : pk;  // physical direction of the peak

    reg [7:0] dir_int [0:32];                         // current intensity per column

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            cur_max <= 9'd0; cur_cell <= 6'd0;
            cur_found <= 1'b0; cur_first <= 6'd0; cur_last <= 6'd0;
            prev_max <= 9'd0; prev_cell <= 6'd16; prev_active <= 1'b0;
            nearest <= 2'd0; sweep_done <= 1'b0;
        end else begin
            sweep_done <= 1'b0;
            if (v3) begin
                if ((c3 == 6'd0) || (lg_s > cur_max)) begin
                    cur_max  <= lg_s;
                    cur_cell <= c3;
                end
                if (c3 == 6'd0) begin
                    cur_found <= hit;
                    cur_first <= c3;
                    cur_last  <= c3;
                end else if (hit) begin
                    if (!cur_found) cur_first <= c3;
                    cur_last  <= c3;
                    cur_found <= 1'b1;
                end
                if (c3 == 6'd32) begin
                    prev_max    <= fm;
                    prev_cell   <= pk;
                    prev_active <= (fm >= gate_log);
                    sweep_done  <= 1'b1;
                    if (fm < gate_log)       nearest <= 2'd0;
                    else if (pdir < 6'd15)   nearest <= 2'd1;
                    else if (pdir > 6'd17)   nearest <= 2'd2;
                    else                     nearest <= 2'd3;
                end
            end
        end
    end

    always @(posedge CLOCK_50)
        if (v3) dir_int[c3] <= inten;

    // =========================================================================
    // 6. History image writer (one row of 33 values every 2^WF_SHIFT sweeps)
    // =========================================================================
    reg [WF_SHIFT-1:0] sweep_cnt;
    reg                wf_busy;
    reg [5:0]          wf_col, wf_row, newest_row;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            sweep_cnt <= {WF_SHIFT{1'b0}};
            wf_busy <= 1'b0; wf_col <= 6'd0; wf_row <= 6'd0; newest_row <= 6'd0;
        end else begin
            if (sweep_done) begin
                sweep_cnt <= sweep_cnt + 1'b1;
                if ((sweep_cnt == {WF_SHIFT{1'b0}}) && !SW[17]) begin
                    wf_busy <= 1'b1;
                    wf_col  <= 6'd0;
                end
            end
            if (wf_busy) begin
                if (wf_col == 6'd32) begin
                    wf_busy    <= 1'b0;
                    newest_row <= wf_row;
                    wf_row     <= wf_row + 6'd1;
                end else begin
                    wf_col <= wf_col + 6'd1;
                end
            end
        end
    end

    // =========================================================================
    // 7. Frequency of each mic
    // =========================================================================
    wire [15:0] freq1, freq2;
    freq_counter_hz #(.GATE_SAMPLES(GATE_SAMPLES)) u_f1 (
        .clk(CLOCK_50), .rst_n(rst_n), .ce(sample_ce), .audio(audio[0]), .freq_bcd(freq1));
    freq_counter_hz #(.GATE_SAMPLES(GATE_SAMPLES)) u_f2 (
        .clk(CLOCK_50), .rst_n(rst_n), .ce(sample_ce), .audio(audio[1]), .freq_bcd(freq2));

    // =========================================================================
    // 8. VGA
    // =========================================================================
    vga_2mic_grid u_vga (
        .clk        (CLOCK_50),
        .rst_n      (rst_n),
        .wf_we      (wf_busy),
        .wf_waddr   ({wf_row, wf_col}),
        .wf_wdata   (dir_int[wf_col]),
        .newest_row (newest_row),
        .lvl1       (lvl[0]),
        .lvl2       (lvl[1]),
        .freq1      (freq1),
        .freq2      (freq2),
        .nearest    (nearest),
        .active     (prev_active),
        .peak_col   (prev_cell),
        .mirror     (SW[16]),
        .vga_clk    (VGA_CLK),
        .vga_hs     (VGA_HS),
        .vga_vs     (VGA_VS),
        .vga_blank_n(VGA_BLANK_N),
        .vga_sync_n (VGA_SYNC_N),
        .vga_r      (VGA_R),
        .vga_g      (VGA_G),
        .vga_b      (VGA_B)
    );

    // =========================================================================
    // 9. LEDs and 7-segment displays (kept for quick checks)
    // =========================================================================
    generate
        for (i = 0; i < 8; i = i + 1) begin : GEN_BARS
            assign LEDR[i]     = (lvl[0] > (i + 3));
            assign LEDR[i + 8] = (lvl[1] > (i + 3));
        end
    endgenerate
    assign LEDR[17:16] = SW[17:16];
    assign LEDG[0]     = (dens[0] >= 8'h60) && (dens[0] <= 8'hA0);
    assign LEDG[1]     = (dens[1] >= 8'h60) && (dens[1] <= 8'hA0);
    assign LEDG[7:2]   = 6'd0;
    assign LEDG[8]     = prev_active;

    function [6:0] seg7(input [3:0] x);
        case (x)
            4'h0: seg7 = 7'b1000000;  4'h1: seg7 = 7'b1111001;
            4'h2: seg7 = 7'b0100100;  4'h3: seg7 = 7'b0110000;
            4'h4: seg7 = 7'b0011001;  4'h5: seg7 = 7'b0010010;
            4'h6: seg7 = 7'b0000010;  4'h7: seg7 = 7'b1111000;
            4'h8: seg7 = 7'b0000000;  4'h9: seg7 = 7'b0010000;
            4'hA: seg7 = 7'b0001000;  4'hB: seg7 = 7'b0000011;
            4'hC: seg7 = 7'b1000110;  4'hD: seg7 = 7'b0100001;
            4'hE: seg7 = 7'b0000110;  default: seg7 = 7'b0001110;
        endcase
    endfunction

    wire [7:0]  l1h = {3'd0, lvl[0]};
    wire [7:0]  l2h = {3'd0, lvl[1]};
    wire [15:0] fsel = (nearest == 2'd2) ? freq2 : freq1;

    assign HEX0 = seg7(fsel[3:0]);
    assign HEX1 = seg7(fsel[7:4]);
    assign HEX2 = seg7(fsel[11:8]);
    assign HEX3 = seg7(fsel[15:12]);
    assign HEX4 = seg7(l2h[3:0]);
    assign HEX5 = seg7(l2h[7:4]);
    assign HEX6 = seg7(l1h[3:0]);
    assign HEX7 = seg7(l1h[7:4]);

endmodule
