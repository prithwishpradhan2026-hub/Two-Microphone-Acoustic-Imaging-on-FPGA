`timescale 1ns / 1ps
// tb_two_mic_grid.v
// -----------------------------------------------------------------------------
// Testbench for de2_115_two_mic_grid_top with two realistic PDM mic models
// (2nd-order sigma-delta, true L/R sharing of one DAT wire, 47 k pull-down as
// tri0, 30.5 mm spacing).
//
// Sequence: 3 kHz tone 50 deg on Mic 1's side -> check peak / nearest
//           tone moved to Mic 2's side           -> check peak / nearest
//           silence                              -> check image goes inactive
// Expected: peak column 0..10, NEAR M01, tag 1 amber, left half red;
//           then 22..32, NEAR M02, right half red; then active = 0 (all blue). About 105 ms simulated; expect several minutes.
// Sim settings: 50 ms frequency gate
// (so the frequency reads 1/20 of the real value: 3000 Hz -> 0150).
// -----------------------------------------------------------------------------

module pdm_mic_model #(
    parameter integer RIGHT = 0,          // 0 = SEL to GND, 1 = SEL to 3.3 V
    parameter integer PX_UM = 0,          // position, micrometres (x right)
    parameter integer PY_UM = 0,          // position, micrometres (y up)
    parameter integer SEED  = 1
)(
    input  wire               clk,
    input  wire signed [15:0] ux_m,       // source direction x, 1/1000 units
    input  wire signed [15:0] uy_m,       // source direction y, 1/1000 units
    input  wire [31:0]        amp_u,      // amplitude, 1e-6 of full scale
    input  wire [31:0]        freq_hz,
    output wire               dat
);
    real x, y, v1, v2, delay_s, noise;
    reg  bit_out, drive;
    integer seed;

    assign dat = drive ? bit_out : 1'bz;

    initial begin
        v1 = 0.0; v2 = 0.0; bit_out = 1'b0; drive = 1'b0; seed = SEED;
    end

    task modulate;
        begin
            delay_s = -((PX_UM * 1.0e-6) * ($itor(ux_m) / 1000.0) +
                        (PY_UM * 1.0e-6) * ($itor(uy_m) / 1000.0)) / 343.0;
            noise = ($random(seed) % 1000) * 3.0e-7;
            x  = (amp_u * 1.0e-6) * $sin(6.283185307 * freq_hz *
                                         ($realtime * 1.0e-9 - delay_s)) + noise;
            y  = bit_out ? 1.0 : -1.0;
            v1 = v1 + 0.5 * (x - y);
            v2 = v2 + 0.5 * (v1 - y);
        end
    endtask

    generate
        if (RIGHT == 0) begin : LEFT_MIC
            always @(posedge clk) begin
                modulate;
                #60;
                bit_out = (v2 >= 0.0);
                drive   = 1'b1;
            end
            always @(negedge clk) begin
                #20 drive = 1'b0;
            end
        end else begin : RIGHT_MIC
            always @(negedge clk) begin
                modulate;
                #60;
                bit_out = (v2 >= 0.0);
                drive   = 1'b1;
            end
            always @(posedge clk) begin
                #20 drive = 1'b0;
            end
        end
    endgenerate
endmodule


module tb_two_mic_grid;

    reg         clk = 1'b0;
    always #10 clk = ~clk;                // 50 MHz

    reg  [0:0]  key;
    reg  [17:0] sw;
    wire        mic_clk;
    tri0        dat0;                     // 47 k pull-down

    wire        vga_clk, vga_hs, vga_vs, vga_blank_n, vga_sync_n;
    wire [7:0]  vga_r, vga_g, vga_b;
    wire [17:0] ledr;
    wire [8:0]  ledg;
    wire [6:0]  h0, h1, h2, h3, h4, h5, h6, h7;

    de2_115_two_mic_grid_top #(.GATE_SAMPLES(9766), .WF_SHIFT(2)) uut (
        .CLOCK_50(clk), .KEY(key), .SW(sw),
        .GPIO_MIC_CLK(mic_clk), .GPIO_MIC_DAT0(dat0),
        .VGA_CLK(vga_clk), .VGA_HS(vga_hs), .VGA_VS(vga_vs),
        .VGA_BLANK_N(vga_blank_n), .VGA_SYNC_N(vga_sync_n),
        .VGA_R(vga_r), .VGA_G(vga_g), .VGA_B(vga_b),
        .LEDR(ledr), .LEDG(ledg),
        .HEX0(h0), .HEX1(h1), .HEX2(h2), .HEX3(h3),
        .HEX4(h4), .HEX5(h5), .HEX6(h6), .HEX7(h7)
    );

    reg signed [15:0] ux, uy;
    reg [31:0]        amp, freq;

    //                    RIGHT  PX_UM  PY_UM SEED
    pdm_mic_model #(0, -15250, 0, 21) mic1 (mic_clk, ux, uy, amp, freq, dat0); // Mic 1, left
    pdm_mic_model #(1,  15250, 0, 22) mic2 (mic_clk, ux, uy, amp, freq, dat0); // Mic 2, right

    // ---------------- status printout every 32 sweeps -----------------------
    integer sweeps = 0;
    always @(posedge clk) begin
        if (uut.sweep_done) begin
            sweeps = sweeps + 1;
            if (sweeps % 32 == 0)
                $display("[%8.3f ms] peak col %0d  nearest %0d  active %b  peak %0.1f oct  lvl1 %0d lvl2 %0d  freq1 %h freq2 %h  mics ok %b",
                         $realtime / 1.0e6, uut.prev_cell, uut.nearest, uut.prev_active,
                         uut.prev_max / 8.0, uut.lvl[0], uut.lvl[1], uut.freq1, uut.freq2, ledg[1:0]);
        end
    end

    initial begin
        key = 1'b0; sw = 18'd0;
        ux = -766; uy = 0;                // 50 deg towards Mic 1
        amp = 30000; freq = 3000;         // -30 dBFS, 3 kHz
        #1000 key = 1'b1;

        $display("--- 3 kHz tone on Mic 1's side ---");
        #40_000_000;
        $display("   [%0.1f ms] peak col %0d, nearest %0d, active %b  (expect col 0..10, nearest 1, active 1)",
                 $realtime / 1.0e6, uut.prev_cell, uut.nearest, uut.prev_active);

        $display("--- tone moved to Mic 2's side ---");
        ux = 766;
        #40_000_000;
        $display("   [%0.1f ms] peak col %0d, nearest %0d, active %b  (expect col 22..32, nearest 2, active 1)",
                 $realtime / 1.0e6, uut.prev_cell, uut.nearest, uut.prev_active);

        $display("--- silence ---");
        amp = 0;
        #25_000_000;
        $display("   active = %b (expect 0), nearest = %0d (expect 0)", uut.prev_active, uut.nearest);
        $finish;
    end

endmodule
