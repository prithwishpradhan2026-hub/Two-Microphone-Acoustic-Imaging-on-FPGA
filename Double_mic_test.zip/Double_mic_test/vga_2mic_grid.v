// vga_2mic_grid.v
// -----------------------------------------------------------------------------
// 640x480 @ 60 Hz screen for the 2-microphone sound locator, in the layout of
// the original acoustic-camera screen, with a 1x2 grid:
//   Square box (384 x 384): left half = Mic 1 side, right half = Mic 2 side.
//     Columns = direction of the sound (33 steering directions, interpolated),
//     rows = time (newest at the top, ~1 s in the box).
//     Colour = sound intensity: LOW blue -> MID cyan/green/yellow -> HIGH red.
//   Corner tags "1" / "2": the nearest mic's tag turns amber.
//   SOURCE DATA panel: NEAR mic, FREQ (kHz), QUAD (half with the peak),
//     LVL1 / LVL2 (mic levels, 1 step = 6 dB).
//   INTENSITY legend: HIGH / MID / LOW colour scale.
// Runs on CLOCK_50 with a 25 MHz pixel enable (single clock domain).
// The text map and font between the GENERATED markers come from gen_2mic_grid.py.
// -----------------------------------------------------------------------------
module vga_2mic_grid (
    input  wire         clk,            // 50 MHz
    input  wire         rst_n,
    input  wire         wf_we,          // history write port
    input  wire [11:0]  wf_waddr,       // {row[5:0], col[5:0]}
    input  wire [7:0]   wf_wdata,
    input  wire [5:0]   newest_row,
    input  wire [4:0]   lvl1, lvl2,
    input  wire [15:0]  freq1, freq2,   // BCD Hz
    input  wire [1:0]   nearest,        // 0 none, 1 Mic 1, 2 Mic 2, 3 equal
    input  wire         active,
    input  wire [5:0]   peak_col,       // screen column 0..32 of the loudest direction
    input  wire         mirror,
    output wire         vga_clk,
    output reg          vga_hs,
    output reg          vga_vs,
    output reg          vga_blank_n,
    output wire         vga_sync_n,
    output reg  [7:0]   vga_r,
    output reg  [7:0]   vga_g,
    output reg  [7:0]   vga_b
);

    assign vga_sync_n = 1'b0;

    // ---------------- pixel clock / enable and raster counters ---------------
    reg clk_vga;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) clk_vga <= 1'b0;
        else        clk_vga <= ~clk_vga;
    assign vga_clk = clk_vga;
    wire pix_ce = clk_vga;              // outputs change 20 ns before vga_clk rises

    reg [9:0] h, v;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            h <= 10'd0; v <= 10'd0;
        end else if (pix_ce) begin
            if (h == 10'd799) begin
                h <= 10'd0;
                v <= (v == 10'd524) ? 10'd0 : v + 10'd1;
            end else begin
                h <= h + 10'd1;
            end
        end
    end

    // ---------------- values shown in the panel -------------------------------
    wire [15:0] fsel = (nearest == 2'd2) ? freq2 : freq1;
    wire [3:0] l1_t = (lvl1 >= 5'd10) ? 4'd1 : 4'd0;
    wire [4:0] l1_m = (lvl1 >= 5'd10) ? (lvl1 - 5'd10) : lvl1;
    wire [3:0] l1_o = l1_m[3:0];
    wire [3:0] l2_t = (lvl2 >= 5'd10) ? 4'd1 : 4'd0;
    wire [4:0] l2_m = (lvl2 >= 5'd10) ? (lvl2 - 5'd10) : lvl2;
    wire [3:0] l2_o = l2_m[3:0];
    wire [1:0] quad = !active ? 2'd0 : (nearest == 2'd3) ? 2'd3 :
                     (((peak_col <= 6'd16) ^ mirror) ? 2'd1 : 2'd2);   // matches the tag numbers

    wire [6:0] tcol = h[9:3];
    wire [5:0] trow = v[8:3];
    wire [2:0] gx   = h[2:0];
    wire [2:0] gy   = v[2:0];

// ===== GENERATED: text map and font =====
    reg [5:0] ch;
    always @(*) begin
        ch = 6'd10;
        case (trow)
            6'd7: begin
                case (tcol)
                    7'd9: case (mirror) 0: ch = 6'd1; 1: ch = 6'd2; default: ch = 6'd10; endcase
                    7'd33: case (mirror) 0: ch = 6'd2; 1: ch = 6'd1; default: ch = 6'd10; endcase
                    7'd59: ch = 6'd31;
                    7'd60: ch = 6'd27;
                    7'd61: ch = 6'd33;
                    7'd62: ch = 6'd30;
                    7'd63: ch = 6'd16;
                    7'd64: ch = 6'd18;
                    7'd66: ch = 6'd17;
                    7'd67: ch = 6'd14;
                    7'd68: ch = 6'd32;
                    7'd69: ch = 6'd14;
                    default: ch = 6'd10;
                endcase
            end
            6'd10: begin
                case (tcol)
                    7'd59: ch = 6'd26;
                    7'd60: ch = 6'd18;
                    7'd61: ch = 6'd14;
                    7'd62: ch = 6'd30;
                    7'd63: ch = 6'd13;
                    7'd65: case (nearest) 0: ch = 6'd11; 1: ch = 6'd25; 2: ch = 6'd25; 3: ch = 6'd18; default: ch = 6'd10; endcase
                    7'd66: case (nearest) 0: ch = 6'd11; 1: ch = 6'd0; 2: ch = 6'd0; 3: ch = 6'd29; default: ch = 6'd10; endcase
                    7'd67: case (nearest) 0: ch = 6'd10; 1: ch = 6'd1; 2: ch = 6'd2; 3: ch = 6'd10; default: ch = 6'd10; endcase
                    default: ch = 6'd10;
                endcase
            end
            6'd12: begin
                case (tcol)
                    7'd59: ch = 6'd19;
                    7'd60: ch = 6'd30;
                    7'd61: ch = 6'd18;
                    7'd62: ch = 6'd29;
                    7'd63: ch = 6'd13;
                    7'd65: ch = {2'b00, fsel[15:12]};
                    7'd66: ch = 6'd12;
                    7'd67: ch = {2'b00, fsel[11:8]};
                    7'd69: ch = 6'd23;
                    7'd70: ch = 6'd21;
                    7'd71: ch = 6'd37;
                    default: ch = 6'd10;
                endcase
            end
            6'd14: begin
                case (tcol)
                    7'd59: ch = 6'd29;
                    7'd60: ch = 6'd33;
                    7'd61: ch = 6'd14;
                    7'd62: ch = 6'd17;
                    7'd63: ch = 6'd13;
                    7'd65: case (quad) 0: ch = 6'd11; 1: ch = 6'd16; 2: ch = 6'd16; 3: ch = 6'd15; default: ch = 6'd10; endcase
                    7'd66: case (quad) 0: ch = 6'd11; 1: ch = 6'd21; 2: ch = 6'd21; 3: ch = 6'd27; default: ch = 6'd10; endcase
                    7'd67: case (quad) 0: ch = 6'd10; 1: ch = 6'd10; 2: ch = 6'd10; 3: ch = 6'd32; default: ch = 6'd10; endcase
                    7'd68: case (quad) 0: ch = 6'd10; 1: ch = 6'd0; 2: ch = 6'd0; 3: ch = 6'd21; default: ch = 6'd10; endcase
                    7'd69: case (quad) 0: ch = 6'd10; 1: ch = 6'd1; 2: ch = 6'd2; 3: ch = 6'd10; default: ch = 6'd10; endcase
                    default: ch = 6'd10;
                endcase
            end
            6'd16: begin
                case (tcol)
                    7'd59: ch = 6'd24;
                    7'd60: ch = 6'd34;
                    7'd61: ch = 6'd24;
                    7'd62: ch = 6'd1;
                    7'd63: ch = 6'd13;
                    7'd65: ch = {2'b00, l1_t};
                    7'd66: ch = {2'b00, l1_o};
                    default: ch = 6'd10;
                endcase
            end
            6'd18: begin
                case (tcol)
                    7'd59: ch = 6'd24;
                    7'd60: ch = 6'd34;
                    7'd61: ch = 6'd24;
                    7'd62: ch = 6'd2;
                    7'd63: ch = 6'd13;
                    7'd65: ch = {2'b00, l2_t};
                    7'd66: ch = {2'b00, l2_o};
                    default: ch = 6'd10;
                endcase
            end
            6'd24: begin
                case (tcol)
                    7'd59: ch = 6'd22;
                    7'd60: ch = 6'd26;
                    7'd61: ch = 6'd32;
                    7'd62: ch = 6'd18;
                    7'd63: ch = 6'd26;
                    7'd64: ch = 6'd31;
                    7'd65: ch = 6'd22;
                    7'd66: ch = 6'd32;
                    7'd67: ch = 6'd36;
                    default: ch = 6'd10;
                endcase
            end
            6'd26: begin
                case (tcol)
                    7'd62: ch = 6'd21;
                    7'd63: ch = 6'd22;
                    7'd64: ch = 6'd20;
                    7'd65: ch = 6'd21;
                    default: ch = 6'd10;
                endcase
            end
            6'd38: begin
                case (tcol)
                    7'd62: ch = 6'd25;
                    7'd63: ch = 6'd22;
                    7'd64: ch = 6'd17;
                    default: ch = 6'd10;
                endcase
            end
            6'd49: begin
                case (tcol)
                    7'd62: ch = 6'd24;
                    7'd63: ch = 6'd27;
                    7'd64: ch = 6'd35;
                    default: ch = 6'd10;
                endcase
            end
            default: ch = 6'd10;
        endcase
    end

    function [4:0] glyph(input [5:0] code, input [2:0] row);
        begin
            glyph = 5'b00000;
            case (code)
                6'd0: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10011; 3'd3: glyph = 5'b10101; 3'd4: glyph = 5'b11001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // '0'
                6'd1: case (row) 3'd0: glyph = 5'b00100; 3'd1: glyph = 5'b01100; 3'd2: glyph = 5'b00100; 3'd3: glyph = 5'b00100; 3'd4: glyph = 5'b00100; 3'd5: glyph = 5'b00100; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // '1'
                6'd2: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b00001; 3'd3: glyph = 5'b00010; 3'd4: glyph = 5'b00100; 3'd5: glyph = 5'b01000; 3'd6: glyph = 5'b11111; default: glyph = 5'b00000; endcase  // '2'
                6'd3: case (row) 3'd0: glyph = 5'b11111; 3'd1: glyph = 5'b00010; 3'd2: glyph = 5'b00100; 3'd3: glyph = 5'b00010; 3'd4: glyph = 5'b00001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // '3'
                6'd4: case (row) 3'd0: glyph = 5'b00010; 3'd1: glyph = 5'b00110; 3'd2: glyph = 5'b01010; 3'd3: glyph = 5'b10010; 3'd4: glyph = 5'b11111; 3'd5: glyph = 5'b00010; 3'd6: glyph = 5'b00010; default: glyph = 5'b00000; endcase  // '4'
                6'd5: case (row) 3'd0: glyph = 5'b11111; 3'd1: glyph = 5'b10000; 3'd2: glyph = 5'b11110; 3'd3: glyph = 5'b00001; 3'd4: glyph = 5'b00001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // '5'
                6'd6: case (row) 3'd0: glyph = 5'b00110; 3'd1: glyph = 5'b01000; 3'd2: glyph = 5'b10000; 3'd3: glyph = 5'b11110; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // '6'
                6'd7: case (row) 3'd0: glyph = 5'b11111; 3'd1: glyph = 5'b00001; 3'd2: glyph = 5'b00010; 3'd3: glyph = 5'b00100; 3'd4: glyph = 5'b01000; 3'd5: glyph = 5'b01000; 3'd6: glyph = 5'b01000; default: glyph = 5'b00000; endcase  // '7'
                6'd8: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b01110; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // '8'
                6'd9: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b01111; 3'd4: glyph = 5'b00001; 3'd5: glyph = 5'b00010; 3'd6: glyph = 5'b01100; default: glyph = 5'b00000; endcase  // '9'
                6'd11: case (row) 3'd0: glyph = 5'b00000; 3'd1: glyph = 5'b00000; 3'd2: glyph = 5'b00000; 3'd3: glyph = 5'b11111; 3'd4: glyph = 5'b00000; 3'd5: glyph = 5'b00000; 3'd6: glyph = 5'b00000; default: glyph = 5'b00000; endcase  // '-'
                6'd12: case (row) 3'd0: glyph = 5'b00000; 3'd1: glyph = 5'b00000; 3'd2: glyph = 5'b00000; 3'd3: glyph = 5'b00000; 3'd4: glyph = 5'b00000; 3'd5: glyph = 5'b01100; 3'd6: glyph = 5'b01100; default: glyph = 5'b00000; endcase  // '.'
                6'd13: case (row) 3'd0: glyph = 5'b00000; 3'd1: glyph = 5'b01100; 3'd2: glyph = 5'b01100; 3'd3: glyph = 5'b00000; 3'd4: glyph = 5'b01100; 3'd5: glyph = 5'b01100; 3'd6: glyph = 5'b00000; default: glyph = 5'b00000; endcase  // ':'
                6'd14: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b11111; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b10001; default: glyph = 5'b00000; endcase  // 'A'
                6'd15: case (row) 3'd0: glyph = 5'b11110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b11110; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b11110; default: glyph = 5'b00000; endcase  // 'B'
                6'd16: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10000; 3'd3: glyph = 5'b10000; 3'd4: glyph = 5'b10000; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // 'C'
                6'd17: case (row) 3'd0: glyph = 5'b11100; 3'd1: glyph = 5'b10010; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b10001; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10010; 3'd6: glyph = 5'b11100; default: glyph = 5'b00000; endcase  // 'D'
                6'd18: case (row) 3'd0: glyph = 5'b11111; 3'd1: glyph = 5'b10000; 3'd2: glyph = 5'b10000; 3'd3: glyph = 5'b11110; 3'd4: glyph = 5'b10000; 3'd5: glyph = 5'b10000; 3'd6: glyph = 5'b11111; default: glyph = 5'b00000; endcase  // 'E'
                6'd19: case (row) 3'd0: glyph = 5'b11111; 3'd1: glyph = 5'b10000; 3'd2: glyph = 5'b10000; 3'd3: glyph = 5'b11110; 3'd4: glyph = 5'b10000; 3'd5: glyph = 5'b10000; 3'd6: glyph = 5'b10000; default: glyph = 5'b00000; endcase  // 'F'
                6'd20: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10000; 3'd3: glyph = 5'b10111; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01111; default: glyph = 5'b00000; endcase  // 'G'
                6'd21: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b11111; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b10001; default: glyph = 5'b00000; endcase  // 'H'
                6'd22: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b00100; 3'd2: glyph = 5'b00100; 3'd3: glyph = 5'b00100; 3'd4: glyph = 5'b00100; 3'd5: glyph = 5'b00100; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // 'I'
                6'd23: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b10010; 3'd2: glyph = 5'b10100; 3'd3: glyph = 5'b11000; 3'd4: glyph = 5'b10100; 3'd5: glyph = 5'b10010; 3'd6: glyph = 5'b10001; default: glyph = 5'b00000; endcase  // 'K'
                6'd24: case (row) 3'd0: glyph = 5'b10000; 3'd1: glyph = 5'b10000; 3'd2: glyph = 5'b10000; 3'd3: glyph = 5'b10000; 3'd4: glyph = 5'b10000; 3'd5: glyph = 5'b10000; 3'd6: glyph = 5'b11111; default: glyph = 5'b00000; endcase  // 'L'
                6'd25: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b11011; 3'd2: glyph = 5'b10101; 3'd3: glyph = 5'b10101; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b10001; default: glyph = 5'b00000; endcase  // 'M'
                6'd26: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b11001; 3'd3: glyph = 5'b10101; 3'd4: glyph = 5'b10011; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b10001; default: glyph = 5'b00000; endcase  // 'N'
                6'd27: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b10001; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // 'O'
                6'd28: case (row) 3'd0: glyph = 5'b11110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b11110; 3'd4: glyph = 5'b10000; 3'd5: glyph = 5'b10000; 3'd6: glyph = 5'b10000; default: glyph = 5'b00000; endcase  // 'P'
                6'd29: case (row) 3'd0: glyph = 5'b01110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b10001; 3'd4: glyph = 5'b10101; 3'd5: glyph = 5'b10010; 3'd6: glyph = 5'b01101; default: glyph = 5'b00000; endcase  // 'Q'
                6'd30: case (row) 3'd0: glyph = 5'b11110; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b11110; 3'd4: glyph = 5'b10100; 3'd5: glyph = 5'b10010; 3'd6: glyph = 5'b10001; default: glyph = 5'b00000; endcase  // 'R'
                6'd31: case (row) 3'd0: glyph = 5'b01111; 3'd1: glyph = 5'b10000; 3'd2: glyph = 5'b10000; 3'd3: glyph = 5'b01110; 3'd4: glyph = 5'b00001; 3'd5: glyph = 5'b00001; 3'd6: glyph = 5'b11110; default: glyph = 5'b00000; endcase  // 'S'
                6'd32: case (row) 3'd0: glyph = 5'b11111; 3'd1: glyph = 5'b00100; 3'd2: glyph = 5'b00100; 3'd3: glyph = 5'b00100; 3'd4: glyph = 5'b00100; 3'd5: glyph = 5'b00100; 3'd6: glyph = 5'b00100; default: glyph = 5'b00000; endcase  // 'T'
                6'd33: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b10001; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b10001; 3'd6: glyph = 5'b01110; default: glyph = 5'b00000; endcase  // 'U'
                6'd34: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b10001; 3'd4: glyph = 5'b10001; 3'd5: glyph = 5'b01010; 3'd6: glyph = 5'b00100; default: glyph = 5'b00000; endcase  // 'V'
                6'd35: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b10001; 3'd3: glyph = 5'b10101; 3'd4: glyph = 5'b10101; 3'd5: glyph = 5'b10101; 3'd6: glyph = 5'b01010; default: glyph = 5'b00000; endcase  // 'W'
                6'd36: case (row) 3'd0: glyph = 5'b10001; 3'd1: glyph = 5'b10001; 3'd2: glyph = 5'b01010; 3'd3: glyph = 5'b00100; 3'd4: glyph = 5'b00100; 3'd5: glyph = 5'b00100; 3'd6: glyph = 5'b00100; default: glyph = 5'b00000; endcase  // 'Y'
                6'd37: case (row) 3'd0: glyph = 5'b11111; 3'd1: glyph = 5'b00001; 3'd2: glyph = 5'b00010; 3'd3: glyph = 5'b00100; 3'd4: glyph = 5'b01000; 3'd5: glyph = 5'b10000; 3'd6: glyph = 5'b11111; default: glyph = 5'b00000; endcase  // 'Z'
                default: glyph = 5'b00000;
            endcase
        end
    endfunction
// ===== END GENERATED =====

    wire [4:0] gbits   = glyph(ch, gy);
    wire       text_on = (gy != 3'd7) && (gx >= 3'd1) && (gx <= 3'd5) && gbits[3'd5 - gx];

    // ---------------- colour scale: LOW blue -> MID green/yellow -> HIGH red -
    function [23:0] heat(input [7:0] s);
        begin
            if (s < 8'd64)       heat = {8'h00, s[5:0], 2'b00, 8'hB8 + {2'b00, s[5:0]}};  // blue -> cyan
            else if (s < 8'd128) heat = {8'h00, 8'hFF, 8'hFF - {s[5:0], 2'b00}};         // cyan -> green
            else if (s < 8'd192) heat = {s[5:0], 2'b00, 8'hFF, 8'h00};                   // green -> yellow
            else                 heat = {8'hFF, 8'hFF - {s[5:0], 2'b00}, 8'h00};         // yellow -> red
        end
    endfunction

    function [7:0] lerp(input [7:0] a, input [7:0] b, input [3:0] f);
        reg [12:0] s;
        begin
            s = a * (5'd16 - {1'b0, f}) + b * {1'b0, f};
            lerp = s[11:4];
        end
    endfunction

    // ---------------- geometry (same box as the original screen) -------------
    localparam BOX_X0 = 64,  BOX_X1 = 448;
    localparam BOX_Y0 = 48,  BOX_Y1 = 432;
    localparam MID_X  = 256;                       // 1x2 divider
    localparam TAG1_X0 = 64,  TAG2_X0 = 256, TAG_W = 32, TAG_Y1 = 84;
    localparam HUD_X0 = 464, HUD_X1 = 632, HUD_Y0 = 48, HUD_Y1 = 168, HUD_SEP = 68;
    localparam LEG_X0 = 472, LEG_X1 = 488, LEG_Y0 = 208, LEG_Y1 = 400;

    wire in_box = (h >= BOX_X0) && (h < BOX_X1) && (v >= BOX_Y0) && (v < BOX_Y1);
    wire [9:0]  rel_x = h - BOX_X0;
    wire [9:0]  rel_y = v - BOX_Y0;
    wire [16:0] xs    = rel_x * 17'd88;            // 384 px -> 33 columns
    wire [5:0]  icol  = (xs[15:10] > 6'd32) ? 6'd32 : xs[15:10];
    wire [5:0]  icoln = (icol == 6'd32) ? 6'd32 : icol + 6'd1;
    wire [3:0]  frac  = xs[9:6];
    wire [5:0]  rvis  = rel_y[8:3];                // 48 rows of 8 px, 0 = newest
    wire [5:0]  wrow  = newest_row - rvis;

    reg  [7:0] wf_ram_a [0:4095];
    reg  [7:0] wf_ram_b [0:4095];
    reg  [7:0] wf_qa, wf_qb;
    always @(posedge clk) begin
        if (wf_we) begin
            wf_ram_a[wf_waddr] <= wf_wdata;
            wf_ram_b[wf_waddr] <= wf_wdata;
        end
        wf_qa <= wf_ram_a[{wrow, icol}];
        wf_qb <= wf_ram_b[{wrow, icoln}];
    end
    wire [7:0] img_v = lerp(wf_qa, wf_qb, frac);

    wire outer_border = (((h >= BOX_X0 - 2) && (h < BOX_X0)) || ((h >= BOX_X1) && (h < BOX_X1 + 2))) &&
                        (v >= BOX_Y0 - 2) && (v < BOX_Y1 + 2) ||
                        (((v >= BOX_Y0 - 2) && (v < BOX_Y0)) || ((v >= BOX_Y1) && (v < BOX_Y1 + 2))) &&
                        (h >= BOX_X0 - 2) && (h < BOX_X1 + 2);
    wire grid_line    = in_box && ((h == MID_X) || (h == MID_X - 1));

    // corner tags (one per half); the nearest mic's tag is amber
    wire in_tag1 = (h >= TAG1_X0) && (h < TAG1_X0 + TAG_W) && (v >= BOX_Y0) && (v < TAG_Y1);
    wire in_tag2 = (h >= TAG2_X0 + 1) && (h < TAG2_X0 + 1 + TAG_W) && (v >= BOX_Y0) && (v < TAG_Y1);
    wire tag_brd = (in_tag1 && ((h == TAG1_X0 + TAG_W - 1) || (h == TAG1_X0 + TAG_W - 2))) ||
                   (in_tag2 && ((h == TAG2_X0 + TAG_W) || (h == TAG2_X0 + TAG_W - 1))) ||
                   ((in_tag1 || in_tag2) && ((v == TAG_Y1 - 1) || (v == TAG_Y1 - 2)));
    wire hl1 = ((nearest == 2'd1) && !mirror) || ((nearest == 2'd2) && mirror) || (nearest == 2'd3);
    wire hl2 = ((nearest == 2'd2) && !mirror) || ((nearest == 2'd1) && mirror) || (nearest == 2'd3);
    wire tag_hl = in_tag1 ? hl1 : hl2;

    // SOURCE DATA panel
    wire in_hud  = (h >= HUD_X0) && (h < HUD_X1) && (v >= HUD_Y0) && (v < HUD_Y1);
    wire hud_brd = in_hud && ((h == HUD_X0) || (h == HUD_X1 - 1) || (v == HUD_Y0) ||
                              (v == HUD_Y1 - 1) || (v == HUD_SEP));
    wire in_hdr  = in_hud && (v < HUD_SEP);

    // INTENSITY legend: HIGH at the top, LOW at the bottom
    wire       in_leg = (h >= LEG_X0) && (h < LEG_X1) && (v >= LEG_Y0) && (v < LEG_Y1);
    wire [9:0] leg_d  = LEG_Y1 - 1 - v;            // 0..191 bottom -> top
    wire [14:0] leg_m = leg_d[7:0] * 7'd85;        // 0..191 -> 0..253 (x 4/3)
    wire [7:0] leg_v  = (leg_d[7:0] > 8'd191) ? 8'd255 : leg_m[13:6];
    wire leg_brd = (h >= LEG_X0 - 1) && (h <= LEG_X1) && (v >= LEG_Y0 - 1) && (v <= LEG_Y1) && !in_leg;

    // text colour
    reg [23:0] tcolor;
    always @(*) begin
        if (trow == 6'd7)        tcolor = 24'h38BDF8;   // header, cyan
        else if (trow == 6'd10)  tcolor = 24'hFBBF24;   // NEAR, amber
        else if (trow == 6'd26)  tcolor = 24'hEF4444;   // HIGH
        else if (trow == 6'd38)  tcolor = 24'hFACC15;   // MID
        else if (trow == 6'd49)  tcolor = 24'h60A5FA;   // LOW
        else if (trow == 6'd24)  tcolor = 24'h38BDF8;   // INTENSITY
        else                     tcolor = 24'hFFFFFF;
    end

    reg [23:0] pix;
    always @(*) begin
        if (outer_border || grid_line || tag_brd) pix = 24'hFFFFFF;
        else if (in_tag1 || in_tag2)              pix = text_on ? (tag_hl ? 24'h111827 : 24'hFFFFFF)
                                                                : (tag_hl ? 24'hFBBF24 : 24'h1E293B);
        else if (in_box)                          pix = heat(img_v);
        else if (hud_brd)                         pix = 24'h38BDF8;
        else if (text_on)                         pix = tcolor;
        else if (in_hdr)                          pix = 24'h1E293B;
        else if (in_hud)                          pix = 24'h0F172A;
        else if (in_leg)                          pix = heat(leg_v);
        else if (leg_brd)                         pix = 24'h64748B;
        else                                      pix = 24'h070D19;
    end

    wire active_area = (h < 10'd640) && (v < 10'd480);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vga_hs <= 1'b1; vga_vs <= 1'b1; vga_blank_n <= 1'b0;
            vga_r <= 8'd0; vga_g <= 8'd0; vga_b <= 8'd0;
        end else if (pix_ce) begin
            vga_hs      <= ~((h >= 10'd656) && (h < 10'd752));
            vga_vs      <= ~((v >= 10'd490) && (v < 10'd492));
            vga_blank_n <= active_area;
            if (active_area) begin
                vga_r <= pix[23:16]; vga_g <= pix[15:8]; vga_b <= pix[7:0];
            end else begin
                vga_r <= 8'd0; vga_g <= 8'd0; vga_b <= 8'd0;
            end
        end
    end

endmodule
