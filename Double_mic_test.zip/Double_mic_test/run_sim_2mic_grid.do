# run_sim_2mic_grid.do  -  ModelSim: do run_sim_2mic_grid.do   (~130 ms simulated, several minutes)
vlib work
vmap work work
vlog pdm_channel.v
vlog mic_ring_buffer_1k.v
vlog freq_counter_hz.v
vlog vga_2mic_grid.v
vlog de2_115_two_mic_grid_top.v
vlog tb_two_mic_grid.v
vsim -voptargs=+acc work.tb_two_mic_grid

add wave -noupdate -divider {Mic bus}
add wave -noupdate /tb_two_mic_grid/mic_clk
add wave -noupdate /tb_two_mic_grid/dat0
add wave -noupdate -divider {Audio}
add wave -noupdate -format Analog-Step -height 40 -min -1500 -max 1500 -radix decimal {/tb_two_mic_grid/uut/GEN_CH[0]/u_ch/audio}
add wave -noupdate -format Analog-Step -height 40 -min -1500 -max 1500 -radix decimal {/tb_two_mic_grid/uut/GEN_CH[1]/u_ch/audio}
add wave -noupdate -divider {Result}
add wave -noupdate -radix unsigned /tb_two_mic_grid/uut/prev_cell
add wave -noupdate -radix unsigned /tb_two_mic_grid/uut/nearest
add wave -noupdate                 /tb_two_mic_grid/uut/prev_active
add wave -noupdate -radix hex      /tb_two_mic_grid/uut/freq1
add wave -noupdate -radix hex      /tb_two_mic_grid/uut/freq2
add wave -noupdate -divider {VGA}
add wave -noupdate /tb_two_mic_grid/vga_hs
add wave -noupdate /tb_two_mic_grid/vga_vs

run -all
wave zoom full
