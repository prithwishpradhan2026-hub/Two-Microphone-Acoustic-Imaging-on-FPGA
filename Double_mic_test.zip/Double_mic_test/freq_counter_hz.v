// freq_counter_hz.v
// -----------------------------------------------------------------------------
// Tone frequency counter (same algorithm as the verified single-mic test).
// Counts rising crossings with adaptive hysteresis (peak/4, min 8) over a gate
// of GATE_SAMPLES samples. With the default gate of exactly 1.000 s the BCD
// count is the frequency in Hz:  bcd[15:12] = kHz, bcd[11:8] = 100 Hz digit.
// Below a peak of 32 nothing is counted (silence reads 0000).
// -----------------------------------------------------------------------------
module freq_counter_hz #(
    parameter integer GATE_SAMPLES = 195312       // 1.000 s at 195.3125 kHz
)(
    input  wire               clk,
    input  wire               rst_n,
    input  wire               ce,                 // 195.3125 kHz sample strobe
    input  wire signed [15:0] audio,
    output reg  [15:0]        freq_bcd
);

    wire [15:0] mag = audio[15] ? (~audio + 16'd1) : audio;
    reg  [15:0] peak;
    reg  [11:0] dcy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            peak <= 16'd0; dcy <= 12'd0;
        end else if (ce) begin
            dcy <= dcy + 12'd1;
            if (mag > peak)        peak <= mag;
            else if (dcy == 12'd0) peak <= peak - ((peak >> 3) | {15'd0, (|peak)});
        end
    end

    wire [15:0]        hyst_raw = peak >> 2;
    wire [15:0]        hyst     = (hyst_raw < 16'd8) ? 16'd8 : hyst_raw;
    wire signed [16:0] a17      = {audio[15], audio};
    wire signed [16:0] h17      = {1'b0, hyst};
    wire               loud     = (peak >= 16'd32);

    function [15:0] bcd_inc(input [15:0] b);
        begin
            bcd_inc = b;
            if (b != 16'h9999) begin
                if (b[3:0] != 4'd9) bcd_inc[3:0] = b[3:0] + 4'd1;
                else begin
                    bcd_inc[3:0] = 4'd0;
                    if (b[7:4] != 4'd9) bcd_inc[7:4] = b[7:4] + 4'd1;
                    else begin
                        bcd_inc[7:4] = 4'd0;
                        if (b[11:8] != 4'd9) bcd_inc[11:8] = b[11:8] + 4'd1;
                        else begin
                            bcd_inc[11:8]  = 4'd0;
                            bcd_inc[15:12] = b[15:12] + 4'd1;
                        end
                    end
                end
            end
        end
    endfunction

    reg        sign_state;
    reg [17:0] gate_cnt;
    reg [15:0] bcd_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sign_state <= 1'b0; gate_cnt <= 18'd0;
            bcd_cnt <= 16'h0000; freq_bcd <= 16'h0000;
        end else if (ce) begin
            if (gate_cnt == GATE_SAMPLES - 1) begin
                gate_cnt <= 18'd0;
                freq_bcd <= bcd_cnt;
                bcd_cnt  <= 16'h0000;
            end else begin
                gate_cnt <= gate_cnt + 18'd1;
                if (!sign_state && (a17 > h17)) begin
                    sign_state <= 1'b1;
                    if (loud) bcd_cnt <= bcd_inc(bcd_cnt);
                end else if (sign_state && (a17 < -h17)) begin
                    sign_state <= 1'b0;
                end
            end
        end
    end

endmodule
