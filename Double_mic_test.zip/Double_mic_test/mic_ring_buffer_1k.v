// mic_ring_buffer_1k.v
// -----------------------------------------------------------------------------
// 1024 x 16-bit audio history for one microphone (infers 2 x M9K).
// Plain simple-dual-port RAM template (no reset on the array or read register)
// so Quartus maps it to block RAM. Read latency = 1 clock.
// 1024 deep so that a full 1.3 ms beamformer frame (L = 256 samples per cell,
// +/-12 sample steering) never reads a location that is being overwritten.
// -----------------------------------------------------------------------------
module mic_ring_buffer_1k (
    input  wire               clk,
    input  wire               we,
    input  wire [9:0]         wr_addr,
    input  wire signed [15:0] din,
    input  wire [9:0]         rd_addr,
    output reg  signed [15:0] dout
);

    reg signed [15:0] mem [0:1023];

    always @(posedge clk) begin
        if (we) mem[wr_addr] <= din;
        dout <= mem[rd_addr];
    end

endmodule
