// =============================================================================
// pdm_channel.v
// -----------------------------------------------------------------------------
// ONE MICROPHONE CHANNEL. The top module uses two copies (Mic 1 and Mic 2).
//
// Input : 1 bit from the mic, 3.125 million times per second (PDM).
// Output: normal 16-bit audio samples, 195,312 times per second (PCM).
//
// Steps inside:
//   1. Health check  - count the 1s in every 1024 bits (about half = OK)
//   2. CIC filter    - average the bits and keep 1 sample out of every 16
//   3. DC blocker    - remove any constant offset
//   4. Low-pass      - remove high-frequency hiss (two simple filters)
//   5. High-pass     - copy without low sounds, used for direction finding
//   6. Level meter   - loudness of the sound in 6 dB steps
//
// Everything runs on the 50 MHz clock. "pdm_ce" is a one-clock pulse that
// says "a new bit is here". This is called a clock enable.
// =============================================================================
module pdm_channel (
    input wire clk,   // 50 MHz clock
    input wire rst_n,   // reset (active low)
    input wire pdm_ce,   // pulse: a new bit has arrived
    input wire pdm_bit,   // the bit from this mic
    output wire signed [15:0] audio,   // clean audio (about +-16384 full scale)
    output wire signed [15:0] audio_hp,   // audio without low sounds (direction finding)
    output reg audio_ce,   // pulse: a new audio sample is ready
    output reg [7:0] density,   // health check: 0x80 = about half 1s
    output wire [4:0] level   // loudness: 1 step = 6 dB
);

    // ---------------- STEP 1: health check (density of 1s) ----------------
    // Count 1024 bits and how many of them are 1. The result divided by 4 is
    // "density": about 0x80 (= 128) for a working mic in a quiet room,
    // 0x00 if the data wire is stuck low, 0xFF if it is stuck high.
    reg [9:0] bit_count;
    reg [10:0] ones_count;
    wire [10:0] ones_count_next = ones_count + {10'd0, pdm_bit};   // count + this bit

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bit_count <= 10'd0; ones_count <= 11'd0; density <= 8'd0;
        end else if (pdm_ce) begin
            bit_count <= bit_count + 10'd1;
            if (bit_count == 10'd1023) begin
                density <= ones_count_next[10] ? 8'hFF : ones_count_next[9:2];   // count / 4 (max 0xFF)
                ones_count <= 11'd0;
            end else begin
                ones_count <= ones_count_next;
            end
        end
    end

    // ---------------- STEP 2: CIC decimation filter ----------------
    // Each bit becomes +1 (bit = 1) or -1 (bit = 0).
    // Three "integrators" are running totals (each adds the one before it).
    // Every 16th bit, three "comb" stages subtract the previous value
    // (comb = now - previous). Integrate 3 times + comb 3 times = averaging over
    // 16 bits three times. It is a good low-pass filter that only needs adders.
    // The output rate is 3.125 MHz / 16 = 195,312 samples per second.
    wire signed [15:0] bit_value = pdm_bit ? 16'sd1 : -16'sd1;

    reg signed [15:0] integrator1, integrator2, integrator3;
    reg signed [15:0] comb0_prev, comb1, comb1_prev, comb2, comb2_prev, comb3;
    reg [3:0] decimate_count;
    reg cic_ready;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            integrator1 <= 16'sd0; integrator2 <= 16'sd0; integrator3 <= 16'sd0;
            comb0_prev <= 16'sd0; comb1 <= 16'sd0; comb1_prev <= 16'sd0;
            comb2 <= 16'sd0; comb2_prev <= 16'sd0; comb3 <= 16'sd0;
            decimate_count <= 4'd0; cic_ready <= 1'b0;
        end else begin
            cic_ready <= 1'b0;
            if (pdm_ce) begin
                integrator1 <= integrator1 + bit_value;   // running total 1
                integrator2 <= integrator2 + integrator1;   // running total 2
                integrator3 <= integrator3 + integrator2;   // running total 3
                decimate_count <= decimate_count + 4'd1;
                if (decimate_count == 4'd15) begin   // every 16th bit:
                    comb1 <= integrator3 - comb0_prev; comb0_prev <= integrator3;   // difference 1
                    comb2 <= comb1 - comb1_prev; comb1_prev <= comb1;   // difference 2
                    comb3 <= comb2 - comb2_prev; comb2_prev <= comb2;   // difference 3 = new audio sample
                    cic_ready <= 1'b1;
                end
            end
        end
    end

    // The CIC output is shifted left by 2 bits (x 4), so a full-scale sound is
    // about +-16384.
    wire signed [15:0] cic_audio = {comb3[13:0], 2'b00};

    // ---------------- STEPS 3 and 4: DC blocker and low-pass filter ----------------
    // dc_average is a very slow average of the signal (it moves 1/256 of the way
    // each sample). Subtracting it removes any constant offset (DC).
    // lowpass1 and lowpass2 are two simple filters: each moves 1/8 of the way
    // towards its input every sample. Two in a row remove hiss above ~4 kHz.
    // The extra 4 bits ("_wide") keep the small fractions so the filter is accurate.
    // The ready pulse is passed along (cic_ready -> no_dc_ready -> audio_ce)
    // so every step knows when its input is new.
    reg signed [23:0] dc_average;
    reg signed [15:0] audio_no_dc;
    reg signed [23:0] lowpass1, lowpass2;
    reg no_dc_ready;

    wire signed [23:0] audio_no_dc_wide = {{4{audio_no_dc[15]}}, audio_no_dc, 4'b0000};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dc_average <= 24'sd0; audio_no_dc <= 16'sd0; lowpass1 <= 24'sd0; lowpass2 <= 24'sd0;
            no_dc_ready <= 1'b0; audio_ce <= 1'b0;
        end else begin
            no_dc_ready <= cic_ready;
            audio_ce <= no_dc_ready;
            if (cic_ready) begin
                dc_average <= dc_average + ({{8{cic_audio[15]}}, cic_audio} - {{8{dc_average[23]}}, dc_average[23:8]});
                audio_no_dc <= cic_audio - dc_average[23:8];   // audio minus its average = no DC
            end
            if (no_dc_ready) begin
                lowpass1 <= lowpass1 + ((audio_no_dc_wide - lowpass1) >>> 3);   // low-pass 1 (>>> 3 = divide by 8)
                lowpass2 <= lowpass2 + ((lowpass1 - lowpass2) >>> 3);   // low-pass 2
            end
        end
    end

    // Clean audio output (used for the level meter and the frequency counter).
    assign audio = lowpass2[19:4];

    // ---------------- STEP 5: high-pass copy for direction finding ----------------
    // slow_average follows the low sounds (moves 1/32 of the way each sample,
    // corner about 1 kHz). audio - slow_average leaves only the higher sounds.
    // Low sounds give no direction information with mics only 3 cm apart.
    reg signed [23:0] slow_average;
    wire signed [23:0] audio_wide = {{4{audio[15]}}, audio, 4'b0000};
    wire signed [23:0] highpass_wide = audio_wide - slow_average;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) slow_average <= 24'sd0;
        else if (audio_ce) slow_average <= slow_average + ((audio_wide - slow_average) >>> 5);
    end

    assign audio_hp = highpass_wide[19:4];   // audio without the low sounds

    // ---------------- STEP 6: level meter ----------------
    // magnitude = size of the sound, ignoring the sign (absolute value).
    // peak_hold jumps up to any bigger value, and every 4096 samples (~21 ms)
    // it drops by 1/8, so it slowly falls when the sound stops.
    wire [15:0] magnitude = audio[15] ? (~audio + 16'd1) : audio;
    reg [15:0] peak_hold;
    reg [11:0] decay_timer;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            peak_hold <= 16'd0; decay_timer <= 12'd0;
        end else if (audio_ce) begin
            decay_timer <= decay_timer + 12'd1;
            if (magnitude > peak_hold) peak_hold <= magnitude;   // new peak
            else if (decay_timer == 12'd0) peak_hold <= peak_hold - ((peak_hold >> 3) | {15'd0, (|peak_hold)});   // slow decay
        end
    end

    // Position of the highest 1 bit (+1) = log2 of the peak.
    // Each step up means the sound is twice as big = +6 dB.
    // Silence is about 2, speech 5-7, a loud tone 9-11.
    function [4:0] top_bit_position(input [15:0] v);
        integer j;
        begin
            top_bit_position = 5'd0;
            for (j = 0; j < 16; j = j + 1)
                if (v[j]) top_bit_position = j + 1;
        end
    endfunction

    assign level = top_bit_position(peak_hold);

endmodule
