# =============================================================================
# two_mic_grid.sdc
# -----------------------------------------------------------------------------
# TIMING CONSTRAINTS for the Quartus Timing Analyzer.
#
# The whole design uses ONE clock, CLOCK_50 (50 MHz). All slower rates
# (3.125 MHz mic clock, 195 kHz audio samples, 25 MHz VGA pixels) are made with
# counters and one-clock "enable" pulses, so no other clocks need to be declared.
# =============================================================================

# CLOCK_50 has a period of 20 ns (50 MHz). Quartus checks that every signal
# travelling from one flip-flop to the next arrives within 20 ns.
create_clock -name {CLOCK_50} -period 20.000 [get_ports {CLOCK_50}]

# Add the small timing uncertainty (jitter) of the clock automatically.
derive_clock_uncertainty

# Inputs that are slow or not related to the clock: the reset button, the
# switches, and the mic data (which first passes through a 2-flop synchronizer).
# "false path" = do not check the timing of these paths.
set_false_path -from [get_ports {KEY[0] SW[*] GPIO_MIC_DAT0}] -to [all_registers]

# Outputs that come straight from flip-flops: the mic clock, the VGA signals
# (they change 20 ns before the VGA clock edge, which is plenty of time),
# the LEDs and the 7-segment displays.
set_false_path -from [all_registers] -to [get_ports {GPIO_MIC_CLK VGA_* LEDR[*] LEDG[*] HEX*[*]}]
