// =============================================================================
// vga_2mic_grid.v
// -----------------------------------------------------------------------------
// VGA SCREEN DRIVER (640 x 480 pixels, 60 frames per second)
//
// The monitor needs the colour of every pixel, sent left to right and top to
// bottom, 25 million pixels per second, plus two timing pulses:
//   HSYNC at the end of every line, VSYNC at the end of every frame.
// This module does NOT store the whole picture. For every pixel position it
// works out the colour on the spot:
//   - white border of the square image box, with a line in the middle (1x2 grid)
//   - inside the box: the sound image (left half = Mic 1 side,
//     right half = Mic 2 side; each row is one moment in time, newest on top)
//   - the small tags "1" and "2" (the nearest mic's tag turns amber)
//   - the SOURCE DATA panel with text: NEAR, FREQ, QUAD, LVL1, LVL2
//   - the INTENSITY colour legend
// Colours: low intensity = blue, middle = cyan/green/yellow, high = red.
// =============================================================================
module vga_2mic_grid (
    input wire clk,   // 50 MHz clock
    input wire rst_n,
    input wire wf_we,   // history memory write enable (from the top module)
    input wire [11:0] wf_waddr,   // write address {row, column}
    input wire [7:0] wf_wdata,   // colour value to write
    input wire [5:0] newest_row,   // which history row is the newest
    input wire [4:0] lvl1, lvl2,   // mic levels (1 step = 6 dB)
    input wire [15:0] freq1, freq2,   // mic frequencies in Hz (BCD digits)
    input wire [1:0] nearest,   // 0 none, 1 Mic 1, 2 Mic 2, 3 equal
    input wire active,   // 1 = sound above the noise gate
    input wire [5:0] peak_col,   // direction (0-32) of the loudest sound
    input wire mirror,   // SW16: swap left and right
    output wire vga_clk,   // 25 MHz pixel clock to the video DAC
    output reg vga_hs,   // horizontal sync
    output reg vga_vs,   // vertical sync
    output reg vga_blank_n,   // 1 = visible pixel
    output wire vga_sync_n,
    output reg [7:0] vga_r,   // red
    output reg [7:0] vga_g,   // green
    output reg [7:0] vga_b   // blue
);

    // Not used by this design (sync is sent on VGA_HS and VGA_VS).
    assign vga_sync_n = 1'b0;

    // ---- Pixel timing ----
    // pixel_toggle flips every 50 MHz clock, giving a 25 MHz clock for the monitor.
    // next_pixel is 1 every second clock: "move on to the next pixel now".
    reg pixel_toggle;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) pixel_toggle <= 1'b0;
        else pixel_toggle <= ~pixel_toggle;
    assign vga_clk = pixel_toggle;
    wire next_pixel = pixel_toggle;

    // x_pos counts 0-799 along a line and y_pos counts 0-524 down the screen.
    // Only x_pos < 640 and y_pos < 480 is visible; the rest is blank time that the
    // monitor needs between lines and frames. 800 x 525 x 60 = about 25 million.
    reg [9:0] x_pos, y_pos;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_pos <= 10'd0; y_pos <= 10'd0;
        end else if (next_pixel) begin
            if (x_pos == 10'd799) begin
                x_pos <= 10'd0;
                y_pos <= (y_pos == 10'd524) ? 10'd0 : y_pos + 10'd1;
            end else begin
                x_pos <= x_pos + 10'd1;
            end
        end
    end

    // ---- Values shown in the SOURCE DATA panel ----
    // freq_of_nearest: frequency of the nearest mic (Mic 1 if none or equal).
    // lvlX_tens / lvlX_ones: the level (0-16) split into two decimal digits.
    // quad_code: 0 = "--", 1 = "CH 01", 2 = "CH 02", 3 = "BOTH".
    wire [15:0] freq_of_nearest = (nearest == 2'd2) ? freq2 : freq1;
    wire [3:0] lvl1_tens = (lvl1 >= 5'd10) ? 4'd1 : 4'd0;
    wire [4:0] lvl1_minus10 = (lvl1 >= 5'd10) ? (lvl1 - 5'd10) : lvl1;
    wire [3:0] lvl1_ones = lvl1_minus10[3:0];
    wire [3:0] lvl2_tens = (lvl2 >= 5'd10) ? 4'd1 : 4'd0;
    wire [4:0] lvl2_minus10 = (lvl2 >= 5'd10) ? (lvl2 - 5'd10) : lvl2;
    wire [3:0] lvl2_ones = lvl2_minus10[3:0];
    wire [1:0] quad_code = !active ? 2'd0 : (nearest == 2'd3) ? 2'd3 :
                     (((peak_col <= 6'd16) ^ mirror) ? 2'd1 : 2'd2);

    // ---- Text ----
    // The screen is divided into small cells of 8 x 8 pixels.
    // text_col / text_row = which cell we are in (x / 8, y / 8).
    // glyph_col / glyph_row = which pixel inside that cell (0-7).
    wire [6:0] text_col = x_pos[9:3];
    wire [5:0] text_row = y_pos[8:3];
    wire [2:0] glyph_col = x_pos[2:0];
    wire [2:0] glyph_row = y_pos[2:0];

    // TEXT MAP: which character is in each cell.
    // Character codes: 0-9 = digits, 10 = space, 11 = '-', 12 = '.', 13 = ':',
    // 14 onwards = letters A, B, C, D, E, F, G, H, I, K, L, M, N, O, P, Q, R, S,
    // T, U, V, W, Y, Z. Example: row 7, columns 59-69 spell "SOURCE DATA".
    // Values such as the frequency digits are taken from the live signals.
    // (This table was generated with a small Python script so the text stays
    // consistent, but it is ordinary Verilog.)
    reg [5:0] char_code;
    always @(*) begin
        char_code = 6'd10;
        case (text_row)
            6'd7: begin
                case (text_col)
                    7'd9: case (mirror) 0: char_code = 6'd1; 1: char_code = 6'd2; default: char_code = 6'd10; endcase
                    7'd33: case (mirror) 0: char_code = 6'd2; 1: char_code = 6'd1; default: char_code = 6'd10; endcase
                    7'd59: char_code = 6'd31;
                    7'd60: char_code = 6'd27;
                    7'd61: char_code = 6'd33;
                    7'd62: char_code = 6'd30;
                    7'd63: char_code = 6'd16;
                    7'd64: char_code = 6'd18;
                    7'd66: char_code = 6'd17;
                    7'd67: char_code = 6'd14;
                    7'd68: char_code = 6'd32;
                    7'd69: char_code = 6'd14;
                    default: char_code = 6'd10;
                endcase
            end
            6'd10: begin
                case (text_col)
                    7'd59: char_code = 6'd26;
                    7'd60: char_code = 6'd18;
                    7'd61: char_code = 6'd14;
                    7'd62: char_code = 6'd30;
                    7'd63: char_code = 6'd13;
                    7'd65: case (nearest) 0: char_code = 6'd11; 1: char_code = 6'd25; 2: char_code = 6'd25; 3: char_code = 6'd18; default: char_code = 6'd10; endcase
                    7'd66: case (nearest) 0: char_code = 6'd11; 1: char_code = 6'd0; 2: char_code = 6'd0; 3: char_code = 6'd29; default: char_code = 6'd10; endcase
                    7'd67: case (nearest) 0: char_code = 6'd10; 1: char_code = 6'd1; 2: char_code = 6'd2; 3: char_code = 6'd10; default: char_code = 6'd10; endcase
                    default: char_code = 6'd10;
                endcase
            end
            6'd12: begin
                case (text_col)
                    7'd59: char_code = 6'd19;
                    7'd60: char_code = 6'd30;
                    7'd61: char_code = 6'd18;
                    7'd62: char_code = 6'd29;
                    7'd63: char_code = 6'd13;
                    7'd65: char_code = {2'b00, freq_of_nearest[15:12]};
                    7'd66: char_code = 6'd12;
                    7'd67: char_code = {2'b00, freq_of_nearest[11:8]};
                    7'd69: char_code = 6'd23;
                    7'd70: char_code = 6'd21;
                    7'd71: char_code = 6'd37;
                    default: char_code = 6'd10;
                endcase
            end
            6'd14: begin
                case (text_col)
                    7'd59: char_code = 6'd29;
                    7'd60: char_code = 6'd33;
                    7'd61: char_code = 6'd14;
                    7'd62: char_code = 6'd17;
                    7'd63: char_code = 6'd13;
                    7'd65: case (quad_code) 0: char_code = 6'd11; 1: char_code = 6'd16; 2: char_code = 6'd16; 3: char_code = 6'd15; default: char_code = 6'd10; endcase
                    7'd66: case (quad_code) 0: char_code = 6'd11; 1: char_code = 6'd21; 2: char_code = 6'd21; 3: char_code = 6'd27; default: char_code = 6'd10; endcase
                    7'd67: case (quad_code) 0: char_code = 6'd10; 1: char_code = 6'd10; 2: char_code = 6'd10; 3: char_code = 6'd32; default: char_code = 6'd10; endcase
                    7'd68: case (quad_code) 0: char_code = 6'd10; 1: char_code = 6'd0; 2: char_code = 6'd0; 3: char_code = 6'd21; default: char_code = 6'd10; endcase
                    7'd69: case (quad_code) 0: char_code = 6'd10; 1: char_code = 6'd1; 2: char_code = 6'd2; 3: char_code = 6'd10; default: char_code = 6'd10; endcase
                    default: char_code = 6'd10;
                endcase
            end
            6'd16: begin
                case (text_col)
                    7'd59: char_code = 6'd24;
                    7'd60: char_code = 6'd34;
                    7'd61: char_code = 6'd24;
                    7'd62: char_code = 6'd1;
                    7'd63: char_code = 6'd13;
                    7'd65: char_code = {2'b00, lvl1_tens};
                    7'd66: char_code = {2'b00, lvl1_ones};
                    default: char_code = 6'd10;
                endcase
            end
            6'd18: begin
                case (text_col)
                    7'd59: char_code = 6'd24;
                    7'd60: char_code = 6'd34;
                    7'd61: char_code = 6'd24;
                    7'd62: char_code = 6'd2;
                    7'd63: char_code = 6'd13;
                    7'd65: char_code = {2'b00, lvl2_tens};
                    7'd66: char_code = {2'b00, lvl2_ones};
                    default: char_code = 6'd10;
                endcase
            end
            6'd24: begin
                case (text_col)
                    7'd59: char_code = 6'd22;
                    7'd60: char_code = 6'd26;
                    7'd61: char_code = 6'd32;
                    7'd62: char_code = 6'd18;
                    7'd63: char_code = 6'd26;
                    7'd64: char_code = 6'd31;
                    7'd65: char_code = 6'd22;
                    7'd66: char_code = 6'd32;
                    7'd67: char_code = 6'd36;
                    default: char_code = 6'd10;
                endcase
            end
            6'd26: begin
                case (text_col)
                    7'd62: char_code = 6'd21;
                    7'd63: char_code = 6'd22;
                    7'd64: char_code = 6'd20;
                    7'd65: char_code = 6'd21;
                    default: char_code = 6'd10;
                endcase
            end
            6'd38: begin
                case (text_col)
                    7'd62: char_code = 6'd25;
                    7'd63: char_code = 6'd22;
                    7'd64: char_code = 6'd17;
                    default: char_code = 6'd10;
                endcase
            end
            6'd49: begin
                case (text_col)
                    7'd62: char_code = 6'd24;
                    7'd63: char_code = 6'd27;
                    7'd64: char_code = 6'd35;
                    default: char_code = 6'd10;
                endcase
            end
            default: char_code = 6'd10;
        endcase
    end

    // FONT: for each character and pixel row (0-6), 5 bits say which of the 5
    // pixel columns are lit (a 5 x 7 pixel font). Example for '1':
    //   00100 / 01100 / 00100 / 00100 / 00100 / 00100 / 01110
    function [4:0] font_lookup(input [5:0] char_in, input [2:0] pixel_row);
        begin
            font_lookup = 5'b00000;
            case (char_in)
                6'd0: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10011; 3'd3: font_lookup = 5'b10101; 3'd4: font_lookup = 5'b11001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd1: case (pixel_row) 3'd0: font_lookup = 5'b00100; 3'd1: font_lookup = 5'b01100; 3'd2: font_lookup = 5'b00100; 3'd3: font_lookup = 5'b00100; 3'd4: font_lookup = 5'b00100; 3'd5: font_lookup = 5'b00100; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd2: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b00001; 3'd3: font_lookup = 5'b00010; 3'd4: font_lookup = 5'b00100; 3'd5: font_lookup = 5'b01000; 3'd6: font_lookup = 5'b11111; default: font_lookup = 5'b00000; endcase
                6'd3: case (pixel_row) 3'd0: font_lookup = 5'b11111; 3'd1: font_lookup = 5'b00010; 3'd2: font_lookup = 5'b00100; 3'd3: font_lookup = 5'b00010; 3'd4: font_lookup = 5'b00001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd4: case (pixel_row) 3'd0: font_lookup = 5'b00010; 3'd1: font_lookup = 5'b00110; 3'd2: font_lookup = 5'b01010; 3'd3: font_lookup = 5'b10010; 3'd4: font_lookup = 5'b11111; 3'd5: font_lookup = 5'b00010; 3'd6: font_lookup = 5'b00010; default: font_lookup = 5'b00000; endcase
                6'd5: case (pixel_row) 3'd0: font_lookup = 5'b11111; 3'd1: font_lookup = 5'b10000; 3'd2: font_lookup = 5'b11110; 3'd3: font_lookup = 5'b00001; 3'd4: font_lookup = 5'b00001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd6: case (pixel_row) 3'd0: font_lookup = 5'b00110; 3'd1: font_lookup = 5'b01000; 3'd2: font_lookup = 5'b10000; 3'd3: font_lookup = 5'b11110; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd7: case (pixel_row) 3'd0: font_lookup = 5'b11111; 3'd1: font_lookup = 5'b00001; 3'd2: font_lookup = 5'b00010; 3'd3: font_lookup = 5'b00100; 3'd4: font_lookup = 5'b01000; 3'd5: font_lookup = 5'b01000; 3'd6: font_lookup = 5'b01000; default: font_lookup = 5'b00000; endcase
                6'd8: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b01110; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd9: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b01111; 3'd4: font_lookup = 5'b00001; 3'd5: font_lookup = 5'b00010; 3'd6: font_lookup = 5'b01100; default: font_lookup = 5'b00000; endcase
                6'd11: case (pixel_row) 3'd0: font_lookup = 5'b00000; 3'd1: font_lookup = 5'b00000; 3'd2: font_lookup = 5'b00000; 3'd3: font_lookup = 5'b11111; 3'd4: font_lookup = 5'b00000; 3'd5: font_lookup = 5'b00000; 3'd6: font_lookup = 5'b00000; default: font_lookup = 5'b00000; endcase
                6'd12: case (pixel_row) 3'd0: font_lookup = 5'b00000; 3'd1: font_lookup = 5'b00000; 3'd2: font_lookup = 5'b00000; 3'd3: font_lookup = 5'b00000; 3'd4: font_lookup = 5'b00000; 3'd5: font_lookup = 5'b01100; 3'd6: font_lookup = 5'b01100; default: font_lookup = 5'b00000; endcase
                6'd13: case (pixel_row) 3'd0: font_lookup = 5'b00000; 3'd1: font_lookup = 5'b01100; 3'd2: font_lookup = 5'b01100; 3'd3: font_lookup = 5'b00000; 3'd4: font_lookup = 5'b01100; 3'd5: font_lookup = 5'b01100; 3'd6: font_lookup = 5'b00000; default: font_lookup = 5'b00000; endcase
                6'd14: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b11111; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b10001; default: font_lookup = 5'b00000; endcase
                6'd15: case (pixel_row) 3'd0: font_lookup = 5'b11110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b11110; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b11110; default: font_lookup = 5'b00000; endcase
                6'd16: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10000; 3'd3: font_lookup = 5'b10000; 3'd4: font_lookup = 5'b10000; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd17: case (pixel_row) 3'd0: font_lookup = 5'b11100; 3'd1: font_lookup = 5'b10010; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b10001; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10010; 3'd6: font_lookup = 5'b11100; default: font_lookup = 5'b00000; endcase
                6'd18: case (pixel_row) 3'd0: font_lookup = 5'b11111; 3'd1: font_lookup = 5'b10000; 3'd2: font_lookup = 5'b10000; 3'd3: font_lookup = 5'b11110; 3'd4: font_lookup = 5'b10000; 3'd5: font_lookup = 5'b10000; 3'd6: font_lookup = 5'b11111; default: font_lookup = 5'b00000; endcase
                6'd19: case (pixel_row) 3'd0: font_lookup = 5'b11111; 3'd1: font_lookup = 5'b10000; 3'd2: font_lookup = 5'b10000; 3'd3: font_lookup = 5'b11110; 3'd4: font_lookup = 5'b10000; 3'd5: font_lookup = 5'b10000; 3'd6: font_lookup = 5'b10000; default: font_lookup = 5'b00000; endcase
                6'd20: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10000; 3'd3: font_lookup = 5'b10111; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01111; default: font_lookup = 5'b00000; endcase
                6'd21: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b11111; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b10001; default: font_lookup = 5'b00000; endcase
                6'd22: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b00100; 3'd2: font_lookup = 5'b00100; 3'd3: font_lookup = 5'b00100; 3'd4: font_lookup = 5'b00100; 3'd5: font_lookup = 5'b00100; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd23: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b10010; 3'd2: font_lookup = 5'b10100; 3'd3: font_lookup = 5'b11000; 3'd4: font_lookup = 5'b10100; 3'd5: font_lookup = 5'b10010; 3'd6: font_lookup = 5'b10001; default: font_lookup = 5'b00000; endcase
                6'd24: case (pixel_row) 3'd0: font_lookup = 5'b10000; 3'd1: font_lookup = 5'b10000; 3'd2: font_lookup = 5'b10000; 3'd3: font_lookup = 5'b10000; 3'd4: font_lookup = 5'b10000; 3'd5: font_lookup = 5'b10000; 3'd6: font_lookup = 5'b11111; default: font_lookup = 5'b00000; endcase
                6'd25: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b11011; 3'd2: font_lookup = 5'b10101; 3'd3: font_lookup = 5'b10101; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b10001; default: font_lookup = 5'b00000; endcase
                6'd26: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b11001; 3'd3: font_lookup = 5'b10101; 3'd4: font_lookup = 5'b10011; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b10001; default: font_lookup = 5'b00000; endcase
                6'd27: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b10001; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd28: case (pixel_row) 3'd0: font_lookup = 5'b11110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b11110; 3'd4: font_lookup = 5'b10000; 3'd5: font_lookup = 5'b10000; 3'd6: font_lookup = 5'b10000; default: font_lookup = 5'b00000; endcase
                6'd29: case (pixel_row) 3'd0: font_lookup = 5'b01110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b10001; 3'd4: font_lookup = 5'b10101; 3'd5: font_lookup = 5'b10010; 3'd6: font_lookup = 5'b01101; default: font_lookup = 5'b00000; endcase
                6'd30: case (pixel_row) 3'd0: font_lookup = 5'b11110; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b11110; 3'd4: font_lookup = 5'b10100; 3'd5: font_lookup = 5'b10010; 3'd6: font_lookup = 5'b10001; default: font_lookup = 5'b00000; endcase
                6'd31: case (pixel_row) 3'd0: font_lookup = 5'b01111; 3'd1: font_lookup = 5'b10000; 3'd2: font_lookup = 5'b10000; 3'd3: font_lookup = 5'b01110; 3'd4: font_lookup = 5'b00001; 3'd5: font_lookup = 5'b00001; 3'd6: font_lookup = 5'b11110; default: font_lookup = 5'b00000; endcase
                6'd32: case (pixel_row) 3'd0: font_lookup = 5'b11111; 3'd1: font_lookup = 5'b00100; 3'd2: font_lookup = 5'b00100; 3'd3: font_lookup = 5'b00100; 3'd4: font_lookup = 5'b00100; 3'd5: font_lookup = 5'b00100; 3'd6: font_lookup = 5'b00100; default: font_lookup = 5'b00000; endcase
                6'd33: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b10001; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b10001; 3'd6: font_lookup = 5'b01110; default: font_lookup = 5'b00000; endcase
                6'd34: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b10001; 3'd4: font_lookup = 5'b10001; 3'd5: font_lookup = 5'b01010; 3'd6: font_lookup = 5'b00100; default: font_lookup = 5'b00000; endcase
                6'd35: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b10001; 3'd3: font_lookup = 5'b10101; 3'd4: font_lookup = 5'b10101; 3'd5: font_lookup = 5'b10101; 3'd6: font_lookup = 5'b01010; default: font_lookup = 5'b00000; endcase
                6'd36: case (pixel_row) 3'd0: font_lookup = 5'b10001; 3'd1: font_lookup = 5'b10001; 3'd2: font_lookup = 5'b01010; 3'd3: font_lookup = 5'b00100; 3'd4: font_lookup = 5'b00100; 3'd5: font_lookup = 5'b00100; 3'd6: font_lookup = 5'b00100; default: font_lookup = 5'b00000; endcase
                6'd37: case (pixel_row) 3'd0: font_lookup = 5'b11111; 3'd1: font_lookup = 5'b00001; 3'd2: font_lookup = 5'b00010; 3'd3: font_lookup = 5'b00100; 3'd4: font_lookup = 5'b01000; 3'd5: font_lookup = 5'b10000; 3'd6: font_lookup = 5'b11111; default: font_lookup = 5'b00000; endcase
                default: font_lookup = 5'b00000;
            endcase
        end
    endfunction

    // text_pixel = 1 when the current pixel is part of a letter.
    // Column 0 and row 7 of each cell are left empty as spacing between letters.
    wire [4:0] glyph_bits = font_lookup(char_code, glyph_row);
    wire text_pixel = (glyph_row != 3'd7) && (glyph_col >= 3'd1) && (glyph_col <= 3'd5) && glyph_bits[3'd5 - glyph_col];

    // ---- Colour map: value 0-255 -> red, green, blue (8 bits each) ----
    //   0-63    blue   -> cyan
    //   64-127  cyan   -> green
    //   128-191 green  -> yellow
    //   192-255 yellow -> red
    function [23:0] colour_map(input [7:0] value);
        begin
            if (value < 8'd64) colour_map = {8'h00, value[5:0], 2'b00, 8'hB8 + {2'b00, value[5:0]}};
            else if (value < 8'd128) colour_map = {8'h00, 8'hFF, 8'hFF - {value[5:0], 2'b00}};
            else if (value < 8'd192) colour_map = {value[5:0], 2'b00, 8'hFF, 8'h00};
            else colour_map = {8'hFF, 8'hFF - {value[5:0], 2'b00}, 8'h00};
        end
    endfunction

    // blend: mixes two neighbouring values for a smooth picture.
    // result = (left x (16 - fraction) + right x fraction) / 16
    function [7:0] blend(input [7:0] left_value, input [7:0] right_value, input [3:0] fraction);
        reg [12:0] value;
        begin
            value = left_value * (5'd16 - {1'b0, fraction}) + right_value * {1'b0, fraction};
            blend = value[11:4];
        end
    endfunction

    // ---- Screen layout (pixel positions) ----
    // BOX = the square image (384 x 384), MID_X = the middle grid line,
    // TAG = the small "1" / "2" boxes, HUD = the SOURCE DATA panel, LEG = legend.
    localparam BOX_X0 = 64, BOX_X1 = 448;
    localparam BOX_Y0 = 48, BOX_Y1 = 432;
    localparam MID_X = 256;
    localparam TAG1_X0 = 64, TAG2_X0 = 256, TAG_W = 32, TAG_Y1 = 84;
    localparam HUD_X0 = 464, HUD_X1 = 632, HUD_Y0 = 48, HUD_Y1 = 168, HUD_SEP = 68;
    localparam LEG_X0 = 472, LEG_X1 = 488, LEG_Y0 = 208, LEG_Y1 = 400;

    // ---- The sound image inside the box ----
    // Horizontally: 384 pixels show 33 directions. x_scaled = box_x x 88 / 1024
    // gives the direction (image_col) and the position between two directions
    // (blend_fraction).
    // Vertically: every 8 pixels is one history row (48 rows). Row 0 at the top is
    // the newest; memory_row finds that row in the history memory.
    wire inside_box = (x_pos >= BOX_X0) && (x_pos < BOX_X1) && (y_pos >= BOX_Y0) && (y_pos < BOX_Y1);
    wire [9:0] box_x = x_pos - BOX_X0;
    wire [9:0] box_y = y_pos - BOX_Y0;
    wire [16:0] x_scaled = box_x * 17'd88;
    wire [5:0] image_col = (x_scaled[15:10] > 6'd32) ? 6'd32 : x_scaled[15:10];
    wire [5:0] image_col_next = (image_col == 6'd32) ? 6'd32 : image_col + 6'd1;
    wire [3:0] blend_fraction = x_scaled[9:6];
    wire [5:0] screen_row = box_y[8:3];
    wire [5:0] memory_row = newest_row - screen_row;

    // History memory: 64 rows x 64 columns of colour values. The top module
    // writes a new row every ~22 ms. There are two identical copies so that two
    // neighbouring directions can be read at the same time (for blending).
    reg [7:0] history_mem_a [0:4095];
    reg [7:0] history_mem_b [0:4095];
    reg [7:0] history_left, history_right;
    always @(posedge clk) begin
        if (wf_we) begin
            history_mem_a[wf_waddr] <= wf_wdata;
            history_mem_b[wf_waddr] <= wf_wdata;
        end
        history_left <= history_mem_a[{memory_row, image_col}];
        history_right <= history_mem_b[{memory_row, image_col_next}];
    end
    wire [7:0] image_value = blend(history_left, history_right, blend_fraction);

    // ---- Borders, tags, panel, legend ----
    // Each of these wires is 1 when the current pixel is in that part of the screen.
    wire outer_border = (((x_pos >= BOX_X0 - 2) && (x_pos < BOX_X0)) || ((x_pos >= BOX_X1) && (x_pos < BOX_X1 + 2))) &&
                        (y_pos >= BOX_Y0 - 2) && (y_pos < BOX_Y1 + 2) ||
                        (((y_pos >= BOX_Y0 - 2) && (y_pos < BOX_Y0)) || ((y_pos >= BOX_Y1) && (y_pos < BOX_Y1 + 2))) &&
                        (x_pos >= BOX_X0 - 2) && (x_pos < BOX_X1 + 2);
    wire grid_line = inside_box && ((x_pos == MID_X) || (x_pos == MID_X - 1));

    wire inside_tag1 = (x_pos >= TAG1_X0) && (x_pos < TAG1_X0 + TAG_W) && (y_pos >= BOX_Y0) && (y_pos < TAG_Y1);
    wire inside_tag2 = (x_pos >= TAG2_X0 + 1) && (x_pos < TAG2_X0 + 1 + TAG_W) && (y_pos >= BOX_Y0) && (y_pos < TAG_Y1);
    wire tag_border = (inside_tag1 && ((x_pos == TAG1_X0 + TAG_W - 1) || (x_pos == TAG1_X0 + TAG_W - 2))) ||
                   (inside_tag2 && ((x_pos == TAG2_X0 + TAG_W) || (x_pos == TAG2_X0 + TAG_W - 1))) ||
                   ((inside_tag1 || inside_tag2) && ((y_pos == TAG_Y1 - 1) || (y_pos == TAG_Y1 - 2)));
    // The tag of the nearest mic is lit (amber). Both are lit when the sound is
    // straight ahead (nearest = 3). SW16 (mirror) swaps the two sides.
    wire tag1_lit = ((nearest == 2'd1) && !mirror) || ((nearest == 2'd2) && mirror) || (nearest == 2'd3);
    wire tag2_lit = ((nearest == 2'd2) && !mirror) || ((nearest == 2'd1) && mirror) || (nearest == 2'd3);
    wire tag_lit = inside_tag1 ? tag1_lit : tag2_lit;

    wire inside_panel = (x_pos >= HUD_X0) && (x_pos < HUD_X1) && (y_pos >= HUD_Y0) && (y_pos < HUD_Y1);
    wire panel_border = inside_panel && ((x_pos == HUD_X0) || (x_pos == HUD_X1 - 1) || (y_pos == HUD_Y0) ||
                              (y_pos == HUD_Y1 - 1) || (y_pos == HUD_SEP));
    wire inside_panel_header = inside_panel && (y_pos < HUD_SEP);

    // The legend is a fixed colour key: value 255 (red) at the top down to 0 (blue).
    wire inside_legend = (x_pos >= LEG_X0) && (x_pos < LEG_X1) && (y_pos >= LEG_Y0) && (y_pos < LEG_Y1);
    wire [9:0] legend_pos = LEG_Y1 - 1 - y_pos;
    wire [14:0] legend_mult = legend_pos[7:0] * 7'd85;
    wire [7:0] legend_value = (legend_pos[7:0] > 8'd191) ? 8'd255 : legend_mult[13:6];
    wire legend_border = (x_pos >= LEG_X0 - 1) && (x_pos <= LEG_X1) && (y_pos >= LEG_Y0 - 1) && (y_pos <= LEG_Y1) && !inside_legend;

    // Text colour depends on the text row (header cyan, NEAR amber, labels).
    reg [23:0] text_colour;
    always @(*) begin
        if (text_row == 6'd7) text_colour = 24'h38BDF8;
        else if (text_row == 6'd10) text_colour = 24'hFBBF24;
        else if (text_row == 6'd26) text_colour = 24'hEF4444;
        else if (text_row == 6'd38) text_colour = 24'hFACC15;
        else if (text_row == 6'd49) text_colour = 24'h60A5FA;
        else if (text_row == 6'd24) text_colour = 24'h38BDF8;
        else text_colour = 24'hFFFFFF;
    end

    // ---- Choose the colour of the current pixel ----
    // This is a priority list: the first true condition decides the colour.
    reg [23:0] pixel_colour;
    always @(*) begin
        if (outer_border || grid_line || tag_border) pixel_colour = 24'hFFFFFF;
        else if (inside_tag1 || inside_tag2) pixel_colour = text_pixel ? (tag_lit ? 24'h111827 : 24'hFFFFFF)
                                                                : (tag_lit ? 24'hFBBF24 : 24'h1E293B);
        else if (inside_box) pixel_colour = colour_map(image_value);
        else if (panel_border) pixel_colour = 24'h38BDF8;
        else if (text_pixel) pixel_colour = text_colour;
        else if (inside_panel_header) pixel_colour = 24'h1E293B;
        else if (inside_panel) pixel_colour = 24'h0F172A;
        else if (inside_legend) pixel_colour = colour_map(legend_value);
        else if (legend_border) pixel_colour = 24'h64748B;
        else pixel_colour = 24'h070D19;
    end

    // ---- Output to the monitor ----
    // On every new pixel: send the sync pulses and the colour (black outside the
    // visible area). The board's ADV7123 chip turns these numbers into the
    // analog voltages the VGA monitor needs.
    wire visible_area = (x_pos < 10'd640) && (y_pos < 10'd480);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vga_hs <= 1'b1; vga_vs <= 1'b1; vga_blank_n <= 1'b0;
            vga_r <= 8'd0; vga_g <= 8'd0; vga_b <= 8'd0;
        end else if (next_pixel) begin
            vga_hs <= ~((x_pos >= 10'd656) && (x_pos < 10'd752));   // low during x = 656-751
            vga_vs <= ~((y_pos >= 10'd490) && (y_pos < 10'd492));   // low during y = 490-491
            vga_blank_n <= visible_area;
            if (visible_area) begin
                vga_r <= pixel_colour[23:16]; vga_g <= pixel_colour[15:8]; vga_b <= pixel_colour[7:0];
            end else begin
                vga_r <= 8'd0; vga_g <= 8'd0; vga_b <= 8'd0;
            end
        end
    end

endmodule
