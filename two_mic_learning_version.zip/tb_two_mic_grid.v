// =============================================================================
// tb_two_mic_grid.v
// -----------------------------------------------------------------------------
// TESTBENCH for ModelSim (it is only for simulation, it is NOT put on the FPGA).
//
// It contains:
//   1. pdm_mic_model : a pretend microphone. It turns a sine wave into 1-bit
//                      PDM data the same way a real MEMS mic does, and drives
//                      the shared DAT wire only in its own clock half.
//   2. tb_two_mic_grid : connects two pretend mics 30.5 mm apart to the real
//                      design and plays a 3 kHz tone from Mic 1's side, then
//                      from Mic 2's side, then silence, and prints the results.
//
// Expected printout:
//   tone on Mic 1's side -> peak column 0..10,  nearest 1, active 1
//   tone on Mic 2's side -> peak column 22..32, nearest 2, active 1
//   silence              -> active 0, nearest 0
// To make the simulation shorter, the frequency is measured over 50 ms
// instead of 1 s, so 3000 Hz is shown as 0150 (1/20). About 105 ms of time is
// simulated; this takes several minutes.
// =============================================================================
`timescale 1ns / 1ps

// -----------------------------------------------------------------------------
// Pretend PDM microphone
//   RIGHT = 0 : behaves like SEL = GND (drives DAT while the clock is high)
//   RIGHT = 1 : behaves like SEL = 3.3 V (drives DAT while the clock is low)
//   PX_UM, PY_UM : position of the mic in micrometres (used for the delay)
// -----------------------------------------------------------------------------
module pdm_mic_model #(
    parameter integer RIGHT = 0,   // 0 = SEL GND (left), 1 = SEL 3.3 V (right)
    parameter integer PX_UM = 0,   // x position in micrometres
    parameter integer PY_UM = 0,
    parameter integer SEED = 1   // seed for the random noise
)(
    input wire clk,   // mic clock from the design
    input wire signed [15:0] ux_m,   // source direction x (x 1/1000)
    input wire signed [15:0] uy_m,
    input wire [31:0] amp_u,   // loudness (x 1/1,000,000 of full scale)
    input wire [31:0] freq_hz,   // tone frequency
    output wire dat   // the shared data wire
);
    // "real" variables hold decimal numbers (simulation only).
    real analog_in, last_output, integrator1, integrator2, delay_seconds, noise;
    reg bit_out, drive;
    integer seed;

    // When the mic is not driving, its output is 'z' (disconnected), so the other
    // mic can use the same wire.
    assign dat = drive ? bit_out : 1'bz;

    initial begin
        integrator1 = 0.0; integrator2 = 0.0; bit_out = 1'b0; drive = 1'b0; seed = SEED;
    end

    // make_next_bit: works out the next PDM bit.
    //   delay_seconds = how much earlier/later the sound reaches this mic,
    //                   from its position and the direction of the source
    //                   (speed of sound = 343 m/s).
    //   analog_in     = the sound at this mic (sine wave + a little noise).
    //   A 2nd-order sigma-delta modulator (two integrators) turns it into bits:
    //   the output bit is 1 when integrator2 is positive, and the integrators
    //   are pushed back by the last output. The density of 1s then follows the sound.
    task make_next_bit;
        begin
            delay_seconds = -((PX_UM * 1.0e-6) * ($itor(ux_m) / 1000.0) +
                        (PY_UM * 1.0e-6) * ($itor(uy_m) / 1000.0)) / 343.0;
            noise = ($random(seed) % 1000) * 3.0e-7;
            analog_in = (amp_u * 1.0e-6) * $sin(6.283185307 * freq_hz *
                                         ($realtime * 1.0e-9 - delay_seconds)) + noise;
            last_output = bit_out ? 1.0 : -1.0;
            integrator1 = integrator1 + 0.5 * (analog_in - last_output);
            integrator2 = integrator2 + 0.5 * (integrator1 - last_output);
        end
    endtask

    // Timing like the real mic: the new bit appears 60 ns after the clock edge
    // of its half, and the mic lets go of the wire 20 ns after the other edge.
    generate
        if (RIGHT == 0) begin : LEFT_MIC
            always @(posedge clk) begin
                make_next_bit;
                #60;
                bit_out = (integrator2 >= 0.0);
                drive = 1'b1;
            end
            always @(negedge clk) begin
                #20 drive = 1'b0;
            end
        end else begin : RIGHT_MIC
            always @(negedge clk) begin
                make_next_bit;
                #60;
                bit_out = (integrator2 >= 0.0);
                drive = 1'b1;
            end
            always @(posedge clk) begin
                #20 drive = 1'b0;
            end
        end
    endgenerate
endmodule

// -----------------------------------------------------------------------------
// The testbench itself
// -----------------------------------------------------------------------------
module tb_two_mic_grid;

    // 50 MHz clock: it flips every 10 ns (period 20 ns).
    reg clk = 1'b0;
    always #10 clk = ~clk;

    reg [0:0] key;
    reg [17:0] sw;
    wire mic_clk;
    // tri0 = a wire that reads 0 when nobody drives it (like the 47 k pull-down).
    tri0 dat0;

    wire vga_clk, vga_hs, vga_vs, vga_blank_n, vga_sync_n;
    wire [7:0] vga_r, vga_g, vga_b;
    wire [17:0] ledr;
    wire [8:0] ledg;
    wire [6:0] h0, h1, h2, h3, h4, h5, h6, h7;

    // The design under test ("uut"). GATE_SAMPLES and WF_SHIFT are made smaller
    // so that the simulation finishes faster.
    de2_115_two_mic_grid_top #(.GATE_SAMPLES(9766), .WF_SHIFT(2)) uut (
        .CLOCK_50(clk), .KEY(key), .SW(sw),
        .GPIO_MIC_CLK(mic_clk), .GPIO_MIC_DAT0(dat0),
        .VGA_CLK(vga_clk), .VGA_HS(vga_hs), .VGA_VS(vga_vs),
        .VGA_BLANK_N(vga_blank_n), .VGA_SYNC_N(vga_sync_n),
        .VGA_R(vga_r), .VGA_G(vga_g), .VGA_B(vga_b),
        .LEDR(ledr), .LEDG(ledg),
        .HEX0(h0), .HEX1(h1), .HEX2(h2), .HEX3(h3),
        .HEX4(h4), .HEX5(h5), .HEX6(h6), .HEX7(h7)
    );

    // Sound source settings: direction (ux = sin of the angle x 1000; negative =
    // Mic 1's side), loudness (amp, in millionths of full scale) and frequency.
    reg signed [15:0] ux, uy;
    reg [31:0] amp, freq;

    // Two pretend mics, 30.5 mm apart (-15.25 mm and +15.25 mm), on one DAT wire.
    pdm_mic_model #(0, -15250, 0, 21) mic1 (mic_clk, ux, uy, amp, freq, dat0);
    pdm_mic_model #(1, 15250, 0, 22) mic2 (mic_clk, ux, uy, amp, freq, dat0);

    // Every 32 sweeps, print what the design has found. "uut.prev_cell" means
    // "the signal prev_cell inside the design" (hierarchical name).
    integer sweeps = 0;
    always @(posedge clk) begin
        if (uut.sweep_done) begin
            sweeps = sweeps + 1;
            if (sweeps % 32 == 0)
                $display("[%8.3f ms] peak col %0d  nearest %0d  active %b  peak %0.1f oct  lvl1 %0d lvl2 %0d  freq1 %h freq2 %h  mics ok %b",
                         $realtime / 1.0e6, uut.prev_cell, uut.nearest, uut.prev_active,
                         uut.prev_max / 8.0, uut.lvl[0], uut.lvl[1], uut.freq1, uut.freq2, ledg[1:0]);
        end
    end

    // The test sequence: reset, tone on Mic 1's side, tone on Mic 2's side,
    // silence. #40_000_000 means "wait 40,000,000 ns = 40 ms".
    initial begin
        key = 1'b0; sw = 18'd0;
        ux = -766; uy = 0;   // sin(-50 degrees) = -0.766: Mic 1's side
        amp = 30000; freq = 3000;   // 3 kHz tone at 3 % of full scale
        #1000 key = 1'b1;   // release reset after 1 us

        $display("--- 3 kHz tone on Mic 1's side ---");
        #40_000_000;
        $display("   [%0.1f ms] peak col %0d, nearest %0d, active %b  (expect col 0..10, nearest 1, active 1)",
                 $realtime / 1.0e6, uut.prev_cell, uut.nearest, uut.prev_active);

        $display("--- tone moved to Mic 2's side ---");
        ux = 766;   // move the source to Mic 2's side
        #40_000_000;
        $display("   [%0.1f ms] peak col %0d, nearest %0d, active %b  (expect col 22..32, nearest 2, active 1)",
                 $realtime / 1.0e6, uut.prev_cell, uut.nearest, uut.prev_active);

        $display("--- silence ---");
        amp = 0;   // silence
        #25_000_000;
        $display("   active = %b (expect 0), nearest = %0d (expect 0)", uut.prev_active, uut.nearest);
        $finish;
    end

endmodule
