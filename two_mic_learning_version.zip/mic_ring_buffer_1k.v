// =============================================================================
// mic_ring_buffer_1k.v
// -----------------------------------------------------------------------------
// AUDIO MEMORY for one microphone: keeps the last 1024 samples (about 5.2 ms).
//
// It is a "ring buffer": the write address goes 0, 1, 2 ... 1023 and then back
// to 0, always writing over the oldest sample, like the hand of a clock.
// Reading at (write address - N) gives the sample from N samples ago, which is
// how the top module delays one microphone relative to the other.
//
// Written in the standard style that Quartus turns into block RAM (M9K).
// The read data appears one clock after the address is given.
// =============================================================================
module mic_ring_buffer_1k (
    input wire clk,
    input wire we,   // write enable: 1 = store din
    input wire [9:0] wr_addr,   // where to write
    input wire signed [15:0] din,   // sample to store
    input wire [9:0] rd_addr,   // where to read
    output reg signed [15:0] dout   // sample read (ready one clock later)
);

    // 1024 words of 16 bits each
    reg signed [15:0] sample_memory [0:1023];

    // Every clock: write if 'we' is 1, and always read one word.
    always @(posedge clk) begin
        if (we) sample_memory[wr_addr] <= din;
        dout <= sample_memory[rd_addr];
    end

endmodule
