// =============================================================================
// de2_115_two_mic_grid_top.v
// -----------------------------------------------------------------------------
// TOP-LEVEL MODULE of the 2-microphone acoustic imaging project (DE2-115 board)
//
// What this design does, in plain words:
//   1. Sends a 3.125 MHz clock to two PDM MEMS microphones and reads their
//      1-bit data from ONE shared wire (Mic 1 talks while the clock is high,
//      Mic 2 talks while the clock is low).
//   2. Turns each mic's bit stream into normal audio samples (pdm_channel.v).
//   3. Stores the latest audio of each mic in a memory (mic_ring_buffer_1k.v).
//   4. Tries 33 different time delays between the mics ("delay-and-sum").
//      The delay that gives the loudest sum tells us the direction of the sound.
//   5. Converts the loudness of each direction into a colour value
//      (red = loudest, then yellow, green, blue).
//   6. Saves one row of colours every ~22 ms so the screen shows a history.
//   7. Measures the frequency of each mic (freq_counter_hz.v).
//   8. Draws everything on a VGA monitor (vga_2mic_grid.v).
//   9. Shows levels and frequency on the LEDs and 7-segment displays too.
//
// Wiring: Mic 1 (left, SEL = GND) and Mic 2 (right, SEL = 3.3 V) share
//         the DAT wire on JP5 pin 3. Their sound ports are 30.5 mm apart.
//
// Switches:  KEY0 = reset
//            SW1-SW0 = colour range (00: 3 dB, 01: 6 dB, 10: 12 dB, 11: 1.5 dB)
//            SW5-SW2 = raise the noise gate (ignore quieter sounds)
//            SW16    = mirror the image left/right
//            SW17    = freeze (hold) the image
//
// Verilog reminders for beginners:
//   reg   = a storage element (flip-flop); it only changes on a clock edge.
//   wire  = a connection; its value is calculated all the time.
//   always @(posedge CLOCK_50)  = "do this at every rising edge of the clock".
//   <=    = register update (all updates in a clock edge happen together).
//   assign = permanent connection / formula.
// =============================================================================
module de2_115_two_mic_grid_top #(
    // ---- Parameters: numbers we can change without editing the logic ----
    parameter integer GATE_SAMPLES = 195312,   // 195312 samples = exactly 1 second (frequency gate)
    parameter integer GATE_BASE = 15,   // default noise gate level
    parameter integer WF_SHIFT = 6   // new image row every 2^6 = 64 sweeps
)(
    // ---- Ports: these names match the real pins (see the .tcl pin file) ----
    input wire CLOCK_50,   // 50 MHz clock from the board
    input wire [0:0] KEY,   // KEY0 push button = reset
    input wire [17:0] SW,   // 18 slide switches
    output wire GPIO_MIC_CLK,   // clock to both mics (JP5 pin 1)
    input wire GPIO_MIC_DAT0,   // shared data wire from both mics (JP5 pin 3)
    output wire VGA_CLK,   // VGA signals to the board's video DAC
    output wire VGA_HS,
    output wire VGA_VS,
    output wire VGA_BLANK_N,
    output wire VGA_SYNC_N,
    output wire [7:0] VGA_R,
    output wire [7:0] VGA_G,
    output wire [7:0] VGA_B,
    output wire [17:0] LEDR,   // red LEDs
    output wire [8:0] LEDG,   // green LEDs
    output wire [6:0] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5, HEX6, HEX7   // 7-segment displays
);

    // KEY0 is the reset button. The buttons give 0 when pressed, so rst_n = 0
    // means "reset now" (the _n at the end of a name means "active low").
    wire rst_n = KEY[0];

    // =============================================================================
    // PART 1: MICROPHONE CLOCK AND READING THE SHARED DATA WIRE
    // =============================================================================
    // A 4-bit counter counts 0,1,2 ... 15 and starts again, once per 50 MHz clock.
    // Its top bit (bit 3) is 0 for counts 0-7 and 1 for counts 8-15, so it is a
    // square wave at 50 MHz / 16 = 3.125 MHz. This is the clock for both mics.
    reg [3:0] clk_div_count;
    always @(posedge CLOCK_50 or negedge rst_n)
        if (!rst_n) clk_div_count <= 4'd0;
        else clk_div_count <= clk_div_count + 4'd1;
    assign GPIO_MIC_CLK = clk_div_count[3];   // 3.125 MHz square wave to the mics

    // The DAT signal comes from outside the FPGA and can change at any moment.
    // Passing it through two flip-flops ("2-flop synchronizer") gives it time to
    // settle so it cannot confuse the logic (this problem is called metastability).
    reg dat_sync1, dat_sync2;
    always @(posedge CLOCK_50) begin
        dat_sync1 <= GPIO_MIC_DAT0;
        dat_sync2 <= dat_sync1;
    end

    // Reading the two mics from one wire:
    //   - Mic 2 (SEL = 3.3 V) drives the wire while the mic clock is LOW
    //     (counter 0-7). We read it at the end of that half, when count = 7.
    //   - Mic 1 (SEL = GND) drives the wire while the mic clock is HIGH
    //     (counter 8-15). We read it at the end of that half, when count = 15.
    // At count 15 we have both bits, so we store them together and give a
    // one-clock "ready" pulse (mic_bits_ready). This pulse is a "clock enable":
    // it tells the next blocks that new bits have arrived (3.125 million per second).
    reg mic2_bit_hold;
    reg [1:0] mic_bits;
    reg mic_bits_ready;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            mic2_bit_hold <= 1'b0; mic_bits <= 2'd0; mic_bits_ready <= 1'b0;
        end else begin
            mic_bits_ready <= 1'b0;
            if (clk_div_count == 4'd7) mic2_bit_hold <= dat_sync2;   // end of clock-low half: Mic 2's bit
            if (clk_div_count == 4'd15) begin
                mic_bits <= {mic2_bit_hold, dat_sync2};   // end of clock-high half: {Mic 2, Mic 1}
                mic_bits_ready <= 1'b1;   // tell pdm_channel: new bits are ready
            end
        end
    end

    // =============================================================================
    // PART 2: TURN EACH MIC'S BITS INTO AUDIO (two copies of pdm_channel)
    // =============================================================================
    // Index [0] = Mic 1, index [1] = Mic 2.
    //   audio      : clean audio, used for the level meter and frequency counter
    //   audio_hp   : the same audio with low sounds (< ~1 kHz) removed,
    //                used for finding the direction
    //   sample_ready_each : pulse when a new audio sample is ready (195,312 per s)
    //   mic_density: health check of the raw bits (about 0x80 = working mic)
    //   lvl        : loudness, 1 step = 6 dB
    wire signed [15:0] audio [0:1];
    wire signed [15:0] audio_hp [0:1];
    wire [1:0] sample_ready_each;
    wire [7:0] mic_density [0:1];
    wire [4:0] lvl [0:1];

    // "generate for" makes two identical copies of pdm_channel, one per mic.
    // GEN_CH[0] is Mic 1 and GEN_CH[1] is Mic 2.
    genvar i;
    generate
        for (i = 0; i < 2; i = i + 1) begin : GEN_CH
            pdm_channel u_ch (
                .clk (CLOCK_50),
                .rst_n (rst_n),
                .pdm_ce (mic_bits_ready),
                .pdm_bit (mic_bits[i]),
                .audio (audio[i]),
                .audio_hp (audio_hp[i]),
                .audio_ce (sample_ready_each[i]),
                .density (mic_density[i]),
                .level (lvl[i])
            );
        end
    endgenerate

    // Both channels produce samples at exactly the same moment,
    // so we use Mic 1's ready pulse for everything.
    wire new_sample = sample_ready_each[0];

    // =============================================================================
    // PART 3: AUDIO MEMORY AND THE DIRECTION SWEEP
    // =============================================================================
    // write_addr is where the next audio sample is written in each mic's memory.
    // It counts 0 ... 1023 and wraps around (a "ring buffer").
    reg [9:0] write_addr;
    always @(posedge CLOCK_50 or negedge rst_n)
        if (!rst_n) write_addr <= 10'd0;
        else if (new_sample) write_addr <= write_addr + 10'd1;   // move to the next memory slot

    // The sweep: for each of 33 directions (direction_index = 0 ... 32, left to
    // right) we look at 512 past samples (sample_index = 0 ... 511).
    // After the last sample of direction 32 we start a new sweep and remember the
    // current write address in sweep_start_addr, so the whole sweep uses the same
    // block of audio. One sweep = 33 x 512 clocks = about 0.34 ms.
    reg [5:0] direction_index;
    reg [8:0] sample_index;
    reg [9:0] sweep_start_addr;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            direction_index <= 6'd0; sample_index <= 9'd0; sweep_start_addr <= 10'd0;
        end else if (sample_index == 9'd511) begin
            sample_index <= 9'd0;
            if (direction_index == 6'd32) begin
                direction_index <= 6'd0;
                sweep_start_addr <= write_addr;   // freeze the starting point for the new sweep
            end else begin
                direction_index <= direction_index + 6'd1;
            end
        end else begin
            sample_index <= sample_index + 9'd1;
        end
    end

    // Which direction are we testing? SW16 can mirror left and right.
    // mic1_delay = 16 - direction gives a trial delay from +16 samples
    // (sound from the far Mic 1 side) to -16 samples (far Mic 2 side).
    // Why +-16? The mics are 30.5 mm apart; sound takes 89 us to travel that far,
    // which is about 17 samples at 195,312 samples per second.
    wire [5:0] steer_dir = SW[16] ? (6'd32 - direction_index) : direction_index;
    wire signed [6:0] mic1_delay = 7'sd16 - $signed({1'b0, steer_dir});

    // Read addresses: Mic 2 is read 20 + sample_index samples in the past
    // (20 makes sure we never read a sample that is not written yet).
    // Mic 1 is read from an address that is mic1_delay samples different.
    // Reading an older or newer address = delaying one mic relative to the other.
    wire [9:0] mic2_read_addr = sweep_start_addr - 10'd20 - {1'b0, sample_index};
    wire [9:0] mic1_read_addr = mic2_read_addr - {{3{mic1_delay[6]}}, mic1_delay};

    // Two memories (one per mic). Each stores the last 1024 audio samples.
    // We write the new sample at write_addr and read the delayed sample back.
    wire signed [15:0] mic1_delayed, mic2_delayed;
    mic_ring_buffer_1k ring_mic1 (
        .clk(CLOCK_50), .we(new_sample), .wr_addr(write_addr), .din(audio_hp[0]),
        .rd_addr(mic1_read_addr), .dout(mic1_delayed)
    );
    mic_ring_buffer_1k ring_mic2 (
        .clk(CLOCK_50), .we(new_sample), .wr_addr(write_addr), .din(audio_hp[1]),
        .rd_addr(mic2_read_addr), .dout(mic2_delayed)
    );

    // =============================================================================
    // PART 4: DELAY-AND-SUM: ADD THE TWO MICS, SQUARE, ADD UP 512 SAMPLES
    // =============================================================================
    // If the trial delay matches the real arrival-time difference, the two waves
    // line up and their sum is large. Squaring gives energy (always positive).
    // The memory needs one clock to give its data, and squaring takes another,
    // so the "last sample" flag and the direction number are delayed by the same
    // two clocks (stage1, stage2). This keeps them lined up with the data.
    // This kind of step-by-step processing is called a pipeline.
    reg last_sample_stage1, last_sample_stage2;
    reg [5:0] dir_stage1, dir_stage2;
    reg [33:0] power_stage2;

    wire signed [16:0] mic_sum = mic1_delayed + mic2_delayed;   // add the two delayed signals
    wire signed [33:0] mic_sum_squared = mic_sum * mic_sum;   // square = energy

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            last_sample_stage1 <= 1'b0; dir_stage1 <= 6'd0;
            last_sample_stage2 <= 1'b0; dir_stage2 <= 6'd0; power_stage2 <= 34'd0;
        end else begin
            last_sample_stage1 <= (sample_index == 9'd511);
            dir_stage1 <= direction_index;
            last_sample_stage2 <= last_sample_stage1;
            dir_stage2 <= dir_stage1;
            power_stage2 <= mic_sum_squared;
        end
    end

    // energy_total adds up the squared sum of 512 samples.
    // At the last sample of a direction, the total is saved as direction_energy,
    // energy_ready gives a one-clock pulse, and energy_total starts again from 0.
    reg [43:0] energy_total, direction_energy;
    reg energy_ready;
    reg [5:0] energy_dir;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            energy_total <= 44'd0; direction_energy <= 44'd0; energy_ready <= 1'b0; energy_dir <= 6'd0;
        end else if (last_sample_stage2) begin
            direction_energy <= energy_total + {10'd0, power_stage2};   // energy of this direction
            energy_total <= 44'd0;
            energy_ready <= 1'b1;
            energy_dir <= dir_stage2;
        end else begin
            energy_total <= energy_total + {10'd0, power_stage2};
            energy_ready <= 1'b0;
        end
    end

    // =============================================================================
    // PART 5: ENERGY -> LOG SCALE -> SMOOTHING -> COLOUR, PEAK AND NEAREST MIC
    // =============================================================================
    // top_bit_position finds the position of the highest 1 bit in a number.
    // That position is the whole-number part of log2(number).
    // Example: 1000 = 0b1111101000, highest 1 bit is bit 9, so log2(1000) is about 9.
    function [5:0] top_bit_position(input [43:0] x);
        integer j;
        begin
            top_bit_position = 6'd0;
            for (j = 0; j < 44; j = j + 1)
                if (x[j]) top_bit_position = j;
        end
    endfunction

    // Stage 1 (s1): remember the energy and find its top bit (log2 whole part).
    // smooth_memory keeps one smoothed value for each of the 33 directions.
    reg s1_valid; reg [5:0] s1_dir; reg [43:0] s1_energy; reg [5:0] s1_exponent;
    reg [14:0] smooth_memory [0:63];
    reg [14:0] smooth_read;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            s1_valid <= 1'b0; s1_dir <= 6'd0; s1_energy <= 44'd0; s1_exponent <= 6'd0;
        end else begin
            s1_valid <= energy_ready;
            if (energy_ready) begin
                s1_dir <= energy_dir;
                s1_energy <= direction_energy;
                s1_exponent <= top_bit_position(direction_energy);   // whole part of log2
            end
        end
    end

    // Stage 2 (s2): take the 3 bits just below the top bit as the fraction of the
    // log, so s2_log_energy = log2(energy) in steps of 1/8.
    // One whole step = energy x 2 = +3 dB. One 1/8 step = about 0.38 dB.
    // We also fetch the old smoothed value of this direction from memory.
    wire [43:0] fraction_shift = (s1_exponent >= 6'd3) ? (s1_energy >> (s1_exponent - 6'd3)) : (s1_energy << (6'd3 - s1_exponent));
    reg s2_valid; reg [5:0] s2_dir; reg [8:0] s2_log_energy; reg [14:0] s2_old_smooth;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            s2_valid <= 1'b0; s2_dir <= 6'd0; s2_log_energy <= 9'd0; s2_old_smooth <= 15'd0;
        end else begin
            s2_valid <= s1_valid;
            if (s1_valid) begin
                s2_dir <= s1_dir;
                s2_log_energy <= {s1_exponent, fraction_shift[2:0]};   // log2 with 3 fraction bits
                s2_old_smooth <= smooth_read;
            end
        end
    end

    // Stage 3 (s3): smoothing. Move 1/64 of the way from the old value to the new
    // value: new_smooth = old + (new - old) / 64. This stops the picture flickering.
    // (>>> 6 means "divide by 64, keeping the sign".)
    wire signed [15:0] smooth_difference = $signed({1'b0, s2_log_energy, 6'b000000}) - $signed({1'b0, s2_old_smooth});
    wire signed [15:0] smooth_step = smooth_difference >>> 6;
    wire signed [15:0] smooth_result = $signed({1'b0, s2_old_smooth}) + smooth_step;
    reg s3_valid; reg [5:0] s3_dir; reg [14:0] s3_smooth;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            s3_valid <= 1'b0; s3_dir <= 6'd0; s3_smooth <= 15'd0;
        end else begin
            s3_valid <= s2_valid;
            if (s2_valid) begin
                s3_dir <= s2_dir;
                s3_smooth <= smooth_result[14:0];
            end
        end
    end

    // Write the smoothed value back into memory, and read the value for the
    // direction that will be processed next.
    always @(posedge CLOCK_50) begin
        if (s3_valid) smooth_memory[s3_dir] <= s3_smooth;
        smooth_read <= smooth_memory[energy_dir];
    end

    // Remove the extra fraction bits used for smoothing: smooth_log is the smoothed
    // log2 energy of this direction (in 1/8 steps).
    wire [8:0] smooth_log = s3_smooth[14:6];

    // Colour window chosen by SW1-SW0: how far below the loudest direction a
    // direction may be and still get colour. 8 steps x 0.38 dB = 3 dB (default).
    // window_shift is used to stretch the window to the full colour range 0-255.
    reg [7:0] window_size; reg [2:0] window_shift;
    always @(*) begin
        case (SW[1:0])
            2'b00: begin window_size = 8'd8; window_shift = 3'd5; end
            2'b01: begin window_size = 8'd16; window_shift = 3'd4; end
            2'b10: begin window_size = 8'd32; window_shift = 3'd3; end
            default: begin window_size = 8'd4; window_shift = 3'd6; end
        endcase
    end

    // Noise gate: if even the loudest direction is quieter than this level,
    // the image is switched off (all blue). SW5-SW2 raise the level.
    localparam [5:0] gate_base_value = GATE_BASE;
    wire [5:0] gate_level = gate_base_value + {2'b00, SW[5:2]};
    wire [8:0] gate_threshold = {gate_level, 3'b000};

    // Results of each sweep:
    //   sweep_max / sweep_max_dir : loudest value found so far in this sweep
    //   prev_max  / prev_cell     : loudest value and peak direction of the LAST sweep
    //   prev_active               : 1 if the last sweep was louder than the noise gate
    //   nearest                   : 0 = none, 1 = Mic 1, 2 = Mic 2, 3 = equal (EQ)
    //   sweep_done                : one-clock pulse at the end of every sweep
    reg [8:0] sweep_max, prev_max;
    reg [5:0] sweep_max_dir, prev_cell;
    reg prev_active;
    reg [1:0] nearest;
    reg sweep_done;

    // Colour value of this direction (0 = blue ... 255 = red):
    //   position_in_window = how far this direction is inside the colour window,
    //   compared with the loudest direction of the last sweep.
    //   Below the window -> 0 (blue). At or above the loudest -> 255 (red).
    //   In between -> scaled to 0-255. If the gate is not passed -> 0.
    wire signed [10:0] position_in_window = $signed({2'b00, smooth_log}) + $signed({3'b000, window_size})
                           - $signed({2'b00, prev_max});
    wire [10:0] position_scaled = position_in_window << window_shift;
    wire [7:0] colour_value = !prev_active ? 8'd0 :
                         position_in_window[10] ? 8'd0 :
                         (position_in_window >= $signed({3'b000, window_size})) ? 8'd255 :
                         position_scaled[7:0];

    // Loudest value of the whole sweep, including the direction being processed now.
    wire [8:0] final_max = (smooth_log > sweep_max) ? smooth_log : sweep_max;
    wire [5:0] final_max_dir = (smooth_log > sweep_max) ? s3_dir : sweep_max_dir;

    // Finding the peak direction:
    // With two mics only 3 cm apart the loudness changes very slowly from one
    // direction to the next, so many directions are almost equally loud.
    // We therefore find the FIRST and LAST direction that are within 0.75 dB
    // (2 steps) of the maximum, and use the MIDDLE of them as the peak.
    // peak_dir_physical undoes the SW16 mirror so "left" always means Mic 1's side.
    wire [8:0] near_peak_threshold = (prev_max > 9'd2) ? (prev_max - 9'd2) : 9'd0;
    wire is_near_peak = (smooth_log >= near_peak_threshold);
    reg near_peak_found;
    reg [5:0] first_near_peak, last_near_peak;
    wire final_found = near_peak_found | is_near_peak;
    wire [5:0] final_first = near_peak_found ? first_near_peak : s3_dir;
    wire [5:0] final_last = is_near_peak ? s3_dir : last_near_peak;
    wire [6:0] first_plus_last = {1'b0, final_first} + {1'b0, final_last};
    wire [5:0] peak_dir = final_found ? first_plus_last[6:1] : final_max_dir;
    wire [5:0] peak_dir_physical = SW[16] ? (6'd32 - peak_dir) : peak_dir;

    // dir_colour holds the current colour value of all 33 directions.
    reg [7:0] dir_colour [0:32];

    // This block runs once per direction (when s3_valid = 1):
    //   - keeps track of the loudest direction in this sweep
    //   - keeps track of the first/last direction near the peak
    //   - at the last direction (32) it saves the results of the sweep and
    //     decides which mic is nearest:
    //       peak left of column 15  -> sound reached Mic 1 first -> nearest = 1
    //       peak right of column 17 -> sound reached Mic 2 first -> nearest = 2
    //       in between              -> straight ahead            -> nearest = 3 (EQ)
    //       below the noise gate    -> no source                 -> nearest = 0
    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            sweep_max <= 9'd0; sweep_max_dir <= 6'd0;
            near_peak_found <= 1'b0; first_near_peak <= 6'd0; last_near_peak <= 6'd0;
            prev_max <= 9'd0; prev_cell <= 6'd16; prev_active <= 1'b0;
            nearest <= 2'd0; sweep_done <= 1'b0;
        end else begin
            sweep_done <= 1'b0;
            if (s3_valid) begin
                if ((s3_dir == 6'd0) || (smooth_log > sweep_max)) begin
                    sweep_max <= smooth_log;
                    sweep_max_dir <= s3_dir;
                end
                if (s3_dir == 6'd0) begin
                    near_peak_found <= is_near_peak;
                    first_near_peak <= s3_dir;
                    last_near_peak <= s3_dir;
                end else if (is_near_peak) begin
                    if (!near_peak_found) first_near_peak <= s3_dir;
                    last_near_peak <= s3_dir;
                    near_peak_found <= 1'b1;
                end
                if (s3_dir == 6'd32) begin
                    prev_max <= final_max;
                    prev_cell <= peak_dir;
                    prev_active <= (final_max >= gate_threshold);   // louder than the noise gate?
                    sweep_done <= 1'b1;
                    if (final_max < gate_threshold) nearest <= 2'd0;   // too quiet: no source
                    else if (peak_dir_physical < 6'd15) nearest <= 2'd1;   // Mic 1 is nearest
                    else if (peak_dir_physical > 6'd17) nearest <= 2'd2;   // Mic 2 is nearest
                    else nearest <= 2'd3;   // straight ahead (EQ)
                end
            end
        end
    end

    // Store the colour value of the direction that was just processed.
    always @(posedge CLOCK_50)
        if (s3_valid) dir_colour[s3_dir] <= colour_value;

    // =============================================================================
    // PART 6: HISTORY IMAGE - SAVE ONE ROW OF COLOURS EVERY 64 SWEEPS (~22 ms)
    // =============================================================================
    // Every 2^WF_SHIFT = 64 sweeps, the 33 colour values are copied one per clock
    // into a new row of the image memory inside the VGA module. newest_row tells
    // the VGA module which row is the newest, so it can draw it at the top.
    // If SW17 is up, no new rows are written, so the picture freezes.
    reg [WF_SHIFT-1:0] sweep_counter;
    reg row_copy_busy;
    reg [5:0] row_copy_col, row_copy_row, newest_row;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            sweep_counter <= {WF_SHIFT{1'b0}};
            row_copy_busy <= 1'b0; row_copy_col <= 6'd0; row_copy_row <= 6'd0; newest_row <= 6'd0;
        end else begin
            if (sweep_done) begin
                sweep_counter <= sweep_counter + 1'b1;
                if ((sweep_counter == {WF_SHIFT{1'b0}}) && !SW[17]) begin
                    row_copy_busy <= 1'b1;
                    row_copy_col <= 6'd0;
                end
            end
            if (row_copy_busy) begin
                if (row_copy_col == 6'd32) begin
                    row_copy_busy <= 1'b0;
                    newest_row <= row_copy_row;
                    row_copy_row <= row_copy_row + 6'd1;
                end else begin
                    row_copy_col <= row_copy_col + 6'd1;
                end
            end
        end
    end

    // =============================================================================
    // PART 7: FREQUENCY OF EACH MICROPHONE (result in Hz, as 4 decimal digits)
    // =============================================================================
    wire [15:0] freq1, freq2;
    freq_counter_hz #(.GATE_SAMPLES(GATE_SAMPLES)) freq_mic1 (
        .clk(CLOCK_50), .rst_n(rst_n), .ce(new_sample), .audio(audio[0]), .freq_bcd(freq1));
    freq_counter_hz #(.GATE_SAMPLES(GATE_SAMPLES)) freq_mic2 (
        .clk(CLOCK_50), .rst_n(rst_n), .ce(new_sample), .audio(audio[1]), .freq_bcd(freq2));

    // =============================================================================
    // PART 8: THE VGA SCREEN
    // =============================================================================
    // The VGA module receives the image rows, levels, frequencies, nearest mic and
    // peak direction, and produces the VGA signals for the monitor.
    vga_2mic_grid screen (
        .clk (CLOCK_50),
        .rst_n (rst_n),
        .wf_we (row_copy_busy),
        .wf_waddr ({row_copy_row, row_copy_col}),
        .wf_wdata (dir_colour[row_copy_col]),
        .newest_row (newest_row),
        .lvl1 (lvl[0]),
        .lvl2 (lvl[1]),
        .freq1 (freq1),
        .freq2 (freq2),
        .nearest (nearest),
        .active (prev_active),
        .peak_col (prev_cell),
        .mirror (SW[16]),
        .vga_clk (VGA_CLK),
        .vga_hs (VGA_HS),
        .vga_vs (VGA_VS),
        .vga_blank_n(VGA_BLANK_N),
        .vga_sync_n (VGA_SYNC_N),
        .vga_r (VGA_R),
        .vga_g (VGA_G),
        .vga_b (VGA_B)
    );

    // =============================================================================
    // PART 9: LEDS AND 7-SEGMENT DISPLAYS (quick checks without the monitor)
    // =============================================================================
    // LEDR0-7 = level bar of Mic 1, LEDR8-15 = level bar of Mic 2
    // (each LED lights when the level is above 3, 4, 5 ... 10).
    generate
        for (i = 0; i < 8; i = i + 1) begin : GEN_BARS
            assign LEDR[i] = (lvl[0] > (i + 3));
            assign LEDR[i + 8] = (lvl[1] > (i + 3));
        end
    endgenerate
    // LEDG0 / LEDG1 light when a mic's bits are about half 1s (healthy mic).
    // LEDG8 lights when the sound is above the noise gate.
    assign LEDR[17:16] = SW[17:16];
    assign LEDG[0] = (mic_density[0] >= 8'h60) && (mic_density[0] <= 8'hA0);
    assign LEDG[1] = (mic_density[1] >= 8'h60) && (mic_density[1] <= 8'hA0);
    assign LEDG[7:2] = 6'd0;
    assign LEDG[8] = prev_active;

    // Converts a number 0-15 into the 7 segments of a display.
    // The DE2-115 segments are "active low": 0 = segment ON, 1 = segment OFF.
    // Bit order: {g, f, e, d, c, b, a}.
    function [6:0] hex_to_7seg(input [3:0] x);
        case (x)
            4'h0: hex_to_7seg = 7'b1000000; 4'h1: hex_to_7seg = 7'b1111001;
            4'h2: hex_to_7seg = 7'b0100100; 4'h3: hex_to_7seg = 7'b0110000;
            4'h4: hex_to_7seg = 7'b0011001; 4'h5: hex_to_7seg = 7'b0010010;
            4'h6: hex_to_7seg = 7'b0000010; 4'h7: hex_to_7seg = 7'b1111000;
            4'h8: hex_to_7seg = 7'b0000000; 4'h9: hex_to_7seg = 7'b0010000;
            4'hA: hex_to_7seg = 7'b0001000; 4'hB: hex_to_7seg = 7'b0000011;
            4'hC: hex_to_7seg = 7'b1000110; 4'hD: hex_to_7seg = 7'b0100001;
            4'hE: hex_to_7seg = 7'b0000110; default: hex_to_7seg = 7'b0001110;
        endcase
    endfunction

    // HEX7-HEX6 = Mic 1 level, HEX5-HEX4 = Mic 2 level,
    // HEX3-HEX0 = frequency (Hz) of the nearest mic.
    wire [7:0] mic1_level_8bit = {3'd0, lvl[0]};
    wire [7:0] mic2_level_8bit = {3'd0, lvl[1]};
    wire [15:0] freq_of_nearest = (nearest == 2'd2) ? freq2 : freq1;

    assign HEX0 = hex_to_7seg(freq_of_nearest[3:0]);
    assign HEX1 = hex_to_7seg(freq_of_nearest[7:4]);
    assign HEX2 = hex_to_7seg(freq_of_nearest[11:8]);
    assign HEX3 = hex_to_7seg(freq_of_nearest[15:12]);
    assign HEX4 = hex_to_7seg(mic2_level_8bit[3:0]);
    assign HEX5 = hex_to_7seg(mic2_level_8bit[7:4]);
    assign HEX6 = hex_to_7seg(mic1_level_8bit[3:0]);
    assign HEX7 = hex_to_7seg(mic1_level_8bit[7:4]);

endmodule
