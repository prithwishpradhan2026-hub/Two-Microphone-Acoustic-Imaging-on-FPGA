// =============================================================================
// freq_counter_hz.v
// -----------------------------------------------------------------------------
// FREQUENCY COUNTER. Counts how many times the sound wave goes up through zero
// in exactly 1 second. That number IS the frequency in Hz.
//
// Two tricks make it reliable:
//   - Hysteresis: the wave must go above +threshold and then below -threshold
//     before the next crossing is counted, so small noise wiggles near zero
//     are not counted. The threshold is 1/4 of the recent peak (at least 8).
//   - Loudness check: nothing is counted if the sound is very quiet,
//     so silence reads 0000.
// The count is kept in BCD (each 4 bits = one decimal digit 0-9), so the
// digits can be shown on the screen directly.
// =============================================================================
module freq_counter_hz #(
    parameter integer GATE_SAMPLES = 195312   // number of samples in 1 second
)(
    input wire clk,
    input wire rst_n,
    input wire ce,   // pulse: a new audio sample is ready
    input wire signed [15:0] audio,   // audio from pdm_channel
    output reg [15:0] freq_bcd   // frequency in Hz as 4 BCD digits
);

    // Peak tracker: the same idea as the level meter in pdm_channel.v.
    // magnitude = absolute value; peak_hold jumps up and slowly decays.
    wire [15:0] magnitude = audio[15] ? (~audio + 16'd1) : audio;
    reg [15:0] peak_hold;
    reg [11:0] decay_timer;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            peak_hold <= 16'd0; decay_timer <= 12'd0;
        end else if (ce) begin
            decay_timer <= decay_timer + 12'd1;
            if (magnitude > peak_hold) peak_hold <= magnitude;
            else if (decay_timer == 12'd0) peak_hold <= peak_hold - ((peak_hold >> 3) | {15'd0, (|peak_hold)});
        end
    end

    // The thresholds for counting a crossing (+threshold and -threshold).
    // The signals are made 17 bits wide and signed so they can be compared
    // with negative numbers safely.
    wire [15:0] threshold_raw = peak_hold >> 2;   // 1/4 of the peak
    wire [15:0] threshold = (threshold_raw < 16'd8) ? 16'd8 : threshold_raw;   // at least 8
    wire signed [16:0] audio_signed17 = {audio[15], audio};
    wire signed [16:0] threshold_signed17 = {1'b0, threshold};
    wire loud_enough = (peak_hold >= 16'd32);   // ignore very quiet sounds

    // Adds 1 to a 4-digit BCD number. Example: 0129 + 1 = 0130.
    // When a digit goes past 9 it becomes 0 and the next digit goes up (carry).
    // It stops at 9999.
    function [15:0] bcd_add_one(input [15:0] bcd_in);
        begin
            bcd_add_one = bcd_in;
            if (bcd_in != 16'h9999) begin
                if (bcd_in[3:0] != 4'd9) bcd_add_one[3:0] = bcd_in[3:0] + 4'd1;
                else begin
                    bcd_add_one[3:0] = 4'd0;
                    if (bcd_in[7:4] != 4'd9) bcd_add_one[7:4] = bcd_in[7:4] + 4'd1;
                    else begin
                        bcd_add_one[7:4] = 4'd0;
                        if (bcd_in[11:8] != 4'd9) bcd_add_one[11:8] = bcd_in[11:8] + 4'd1;
                        else begin
                            bcd_add_one[11:8] = 4'd0;
                            bcd_add_one[15:12] = bcd_in[15:12] + 4'd1;
                        end
                    end
                end
            end
        end
    endfunction

    // Main counter:
    //   gate_timer counts samples. After GATE_SAMPLES (= 1 second) the count is
    //   copied to freq_bcd (the output) and counting starts again.
    //   wave_is_high remembers whether the wave is in its "high" part, so each
    //   cycle of the wave is counted only once.
    reg wave_is_high;
    reg [17:0] gate_timer;
    reg [15:0] crossing_count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wave_is_high <= 1'b0; gate_timer <= 18'd0;   // the wave went down through -threshold
            crossing_count <= 16'h0000; freq_bcd <= 16'h0000;
        end else if (ce) begin
            if (gate_timer == GATE_SAMPLES - 1) begin
                gate_timer <= 18'd0;
                freq_bcd <= crossing_count;   // 1 second is over: show the result
                crossing_count <= 16'h0000;
            end else begin
                gate_timer <= gate_timer + 18'd1;
                if (!wave_is_high && (audio_signed17 > threshold_signed17)) begin
                    wave_is_high <= 1'b1;   // the wave went up through +threshold
                    if (loud_enough) crossing_count <= bcd_add_one(crossing_count);   // count one cycle
                end else if (wave_is_high && (audio_signed17 < -threshold_signed17)) begin
                    wave_is_high <= 1'b0;
                end
            end
        end
    end

endmodule
